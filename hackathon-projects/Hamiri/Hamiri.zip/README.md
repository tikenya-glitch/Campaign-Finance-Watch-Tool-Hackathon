
  # Hamiri

  This is a code bundle for Hamiri. The original project is available at https://www.figma.com/design/FMIaqCXKxqv3g9ehlJyqDD/Hamiri.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  