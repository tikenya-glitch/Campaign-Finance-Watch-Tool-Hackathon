import React from 'react';
import { HeroSection } from './components/hero-section';
import { ArchitectureDiagram } from './components/architecture-diagram';
import { DataFlowVisualization } from './components/data-flow-visualization';
import { USSDFlowDemo } from './components/ussd-flow-demo';
import { WhatsAppFlowDemo } from './components/whatsapp-flow-demo';
import { TechnicalStack } from './components/technical-stack';
import { InteractiveMapDemo } from './components/interactive-map-demo';
import { EnhancedDashboard } from './components/enhanced-dashboard';

export default function App() {
  return (
    <div className="w-full min-h-screen bg-gray-50">
      {/* Hero Section */}
      <HeroSection />

      {/* Main Content */}
      <div className="bg-white">
        {/* Section Divider */}
        <div className="h-2 bg-gradient-to-r from-[#ff3a21] to-[#0b65b1]"></div>

        {/* What is Hamiri.ke */}
        <section className="py-20 px-6 bg-gray-50">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-4xl font-bold text-center mb-6">
              What is <span style={{ color: '#ff3a21' }}>Hamiri</span>
              <span style={{ color: '#0b65b1' }}>.</span>
              <span style={{ color: '#ff3a21' }}>ke</span>?
            </h2>
            <div className="max-w-4xl mx-auto space-y-6 text-lg text-gray-700">
              <p className="leading-relaxed">
                <strong style={{ color: '#ff3a21' }}>Hamiri Ke</strong> is a <strong>campaign finance watch tool</strong> — 
                a digital platform that tracks, visualizes, and monitors political financing in Kenya by combining official 
                disclosure data with ground-level community signals to expose the gap between what candidates declare and 
                what they actually spend.
              </p>
              <p className="leading-relaxed">
                The core engine is a <strong style={{ color: '#0b65b1' }}>data platform</strong>. WhatsApp and USSD are not 
                the product — they are the <strong>data collection and dissemination layers</strong> that feed the platform 
                from the ground up, reaching every Kenyan regardless of smartphone access or literacy.
              </p>
              <div className="bg-white rounded-xl p-6 shadow-lg border-l-4" style={{ borderLeftColor: '#ff3a21' }}>
                <p className="font-semibold text-gray-900 italic">
                  "The 2027 election will be the first in Kenyan history where the gap between declared campaign finance 
                  and actual ground-level spending is not just known — it is <strong style={{ color: '#0b65b1' }}>visible, 
                  mapped, timestamped, and impossible to deny</strong>."
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Divider */}
        <div className="h-1 bg-gradient-to-r from-[#0b65b1] to-[#ff3a21]"></div>

        {/* Enhanced Dashboard - NEW */}
        <section className="py-20 px-6 bg-gray-50">
          <EnhancedDashboard />
        </section>

        {/* Divider */}
        <div className="h-1 bg-gradient-to-r from-[#ff3a21] to-[#0b65b1]"></div>

        {/* Architecture Diagram */}
        <section className="py-20 px-6 bg-white">
          <ArchitectureDiagram />
        </section>

        {/* Divider */}
        <div className="h-1 bg-gradient-to-r from-[#ff3a21] to-[#0b65b1]"></div>

        {/* Data Flow Visualization */}
        <section className="py-20 px-6 bg-gray-50">
          <DataFlowVisualization />
        </section>

        {/* Divider */}
        <div className="h-1 bg-gradient-to-r from-[#0b65b1] to-[#ff3a21]"></div>

        {/* USSD Demo */}
        <section className="py-20 px-6 bg-white">
          <USSDFlowDemo />
        </section>

        {/* Divider */}
        <div className="h-1 bg-gradient-to-r from-[#ff3a21] to-[#0b65b1]"></div>

        {/* WhatsApp Demo */}
        <section className="py-20 px-6 bg-gray-50">
          <WhatsAppFlowDemo />
        </section>

        {/* Divider */}
        <div className="h-1 bg-gradient-to-r from-[#0b65b1] to-[#ff3a21]"></div>

        {/* Interactive Map Demo */}
        <section className="py-20 px-6 bg-white">
          <InteractiveMapDemo />
        </section>

        {/* Divider */}
        <div className="h-1 bg-gradient-to-r from-[#ff3a21] to-[#0b65b1]"></div>

        {/* Technical Stack */}
        <section className="py-20 px-6 bg-gray-50">
          <TechnicalStack />
        </section>

        {/* Divider */}
        <div className="h-1 bg-gradient-to-r from-[#0b65b1] to-[#ff3a21]"></div>

        {/* How It Works Summary */}
        <section className="py-20 px-6 bg-white">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-4xl font-bold text-center mb-12">
              How <span style={{ color: '#ff3a21' }}>Hamiri.ke</span> Works: End-to-End
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Collection */}
              <div className="bg-gradient-to-br from-[#ff3a21]/10 to-[#ff3a21]/5 rounded-xl p-8 border-2" style={{ borderColor: '#ff3a21' }}>
                <div className="text-4xl mb-4">📱</div>
                <h3 className="text-2xl font-bold mb-4" style={{ color: '#ff3a21' }}>1. Citizen Collection</h3>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-start gap-2">
                    <span style={{ color: '#ff3a21' }}>▸</span>
                    <span>Citizens dial <strong>*384*96#</strong> (USSD) or chat with <strong>WhatsApp Bot</strong></span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span style={{ color: '#ff3a21' }}>▸</span>
                    <span>Answer one simple question in <strong>Kiswahili, Sheng, or English</strong></span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span style={{ color: '#ff3a21' }}>▸</span>
                    <span><strong>Completely anonymous</strong> - no personal data stored</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span style={{ color: '#ff3a21' }}>▸</span>
                    <span>Works on any phone, no internet required for USSD</span>
                  </li>
                </ul>
              </div>

              {/* Processing */}
              <div className="bg-gradient-to-br from-[#0b65b1]/10 to-[#0b65b1]/5 rounded-xl p-8 border-2" style={{ borderColor: '#0b65b1' }}>
                <div className="text-4xl mb-4">⚙️</div>
                <h3 className="text-2xl font-bold mb-4" style={{ color: '#0b65b1' }}>2. Data Processing</h3>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-start gap-2">
                    <span style={{ color: '#0b65b1' }}>▸</span>
                    <span>Signals aggregated at <strong>ward level</strong> (no individual tracking)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span style={{ color: '#0b65b1' }}>▸</span>
                    <span>Cross-referenced with <strong>IEBC official declarations</strong></span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span style={{ color: '#0b65b1' }}>▸</span>
                    <span><strong>Anomaly detection</strong> algorithms flag discrepancies</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span style={{ color: '#0b65b1' }}>▸</span>
                    <span>Real-time expenditure estimates calculated</span>
                  </li>
                </ul>
              </div>

              {/* Visualization */}
              <div className="bg-gradient-to-br from-[#ff3a21]/10 to-[#ff3a21]/5 rounded-xl p-8 border-2" style={{ borderColor: '#ff3a21' }}>
                <div className="text-4xl mb-4">📊</div>
                <h3 className="text-2xl font-bold mb-4" style={{ color: '#ff3a21' }}>3. Public Dashboard</h3>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-start gap-2">
                    <span style={{ color: '#ff3a21' }}>▸</span>
                    <span><strong>Interactive heat maps</strong> showing vote-buying intensity by county</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span style={{ color: '#ff3a21' }}>▸</span>
                    <span><strong>Candidate profiles</strong> comparing declared vs. estimated spending</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span style={{ color: '#ff3a21' }}>▸</span>
                    <span><strong>Week-on-week trends</strong> showing spending patterns over time</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span style={{ color: '#ff3a21' }}>▸</span>
                    <span><strong>Traffic light indicators</strong> (Green/Yellow/Red) for compliance</span>
                  </li>
                </ul>
              </div>

              {/* Accountability */}
              <div className="bg-gradient-to-br from-[#0b65b1]/10 to-[#0b65b1]/5 rounded-xl p-8 border-2" style={{ borderColor: '#0b65b1' }}>
                <div className="text-4xl mb-4">🎯</div>
                <h3 className="text-2xl font-bold mb-4" style={{ color: '#0b65b1' }}>4. Accountability Action</h3>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-start gap-2">
                    <span style={{ color: '#0b65b1' }}>▸</span>
                    <span><strong>Journalists</strong> download anomaly reports for investigative stories</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span style={{ color: '#0b65b1' }}>▸</span>
                    <span><strong>IEBC</strong> receives mathematical contradiction flags</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span style={{ color: '#0b65b1' }}>▸</span>
                    <span><strong>Civil society</strong> monitors real-time compliance</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span style={{ color: '#0b65b1' }}>▸</span>
                    <span><strong>Public</strong> shares simple ward summaries on social media</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Key Differentiator */}
            <div className="mt-12 bg-gradient-to-r from-[#ff3a21] to-[#0b65b1] rounded-xl p-8 text-white">
              <h3 className="text-2xl font-bold mb-4 text-center">The Hamiri.ke Difference</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
                <div>
                  <div className="text-4xl mb-2">🔍</div>
                  <h4 className="font-bold mb-2">Ushahidi documents what went wrong</h4>
                  <p className="text-sm opacity-90">Election day incident mapping</p>
                </div>
                <div>
                  <div className="text-4xl mb-2">💰</div>
                  <h4 className="font-bold mb-2">Hamiri.ke follows the money</h4>
                  <p className="text-sm opacity-90">12 weeks before election day</p>
                </div>
                <div>
                  <div className="text-4xl mb-2">⚡</div>
                  <h4 className="font-bold mb-2">Before it does damage</h4>
                  <p className="text-sm opacity-90">Preventive, not reactive</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Divider */}
        <div className="h-1 bg-gradient-to-r from-[#ff3a21] to-[#0b65b1]"></div>

        {/* Footer */}
        <footer className="bg-gray-900 text-white py-12 px-6">
          <div className="max-w-6xl mx-auto text-center">
            <h3 className="text-3xl font-bold mb-4">
              <span style={{ color: '#ff3a21' }}>HAMIRI</span>
              <span style={{ color: '#0b65b1' }}>.</span>
              <span style={{ color: '#ff3a21' }}>KE</span>
            </h3>
            <p className="text-gray-400 mb-6 max-w-2xl mx-auto">
              Making campaign finance transparent, one citizen signal at a time.
            </p>
            <div className="flex justify-center gap-6 mb-8">
              <a href="#" className="hover:underline" style={{ color: '#ff3a21' }}>Platform</a>
              <a href="#" className="hover:underline" style={{ color: '#0b65b1' }}>Documentation</a>
              <a href="#" className="hover:underline" style={{ color: '#ff3a21' }}>API</a>
              <a href="#" className="hover:underline" style={{ color: '#0b65b1' }}>Contact</a>
            </div>
            <p className="text-sm text-gray-600">
              © 2027 Hamiri.ke - Campaign Finance Watch Tool | Built for Kenyan Accountability
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
}