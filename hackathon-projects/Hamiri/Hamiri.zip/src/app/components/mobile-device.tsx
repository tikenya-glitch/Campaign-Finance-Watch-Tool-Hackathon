import React from 'react';

interface MobileDeviceProps {
  variant?: 'ios' | 'android' | 'feature';
  children: React.ReactNode;
  className?: string;
}

export function MobileDevice({ variant = 'android', children, className = '' }: MobileDeviceProps) {
  const isFeaturePhone = variant === 'feature';
  
  return (
    <div className={`relative ${className}`}>
      {/* Phone Frame */}
      <div className={`
        relative bg-gray-900 rounded-[2.5rem] p-3 shadow-2xl
        ${isFeaturePhone ? 'w-48 h-96' : 'w-64 h-[550px]'}
      `}>
        {/* Notch or Speaker */}
        {!isFeaturePhone && (
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-gray-900 rounded-b-2xl z-10">
            <div className="w-12 h-1 bg-gray-800 rounded-full mx-auto mt-2"></div>
          </div>
        )}
        
        {/* Screen */}
        <div className={`
          bg-white h-full rounded-[1.8rem] overflow-hidden relative
          ${isFeaturePhone ? 'rounded-lg' : ''}
        `}>
          {/* Status Bar */}
          <div className="bg-white px-4 py-2 flex justify-between items-center text-xs border-b">
            <div className="flex items-center gap-1">
              <div className="w-4 h-3 border border-gray-800 rounded-sm relative">
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-0.5 h-1 bg-gray-800"></div>
                <div className="absolute left-0.5 top-0.5 bottom-0.5 right-1 bg-gray-800"></div>
              </div>
              <span className="text-gray-800">3:47</span>
            </div>
            <div className="flex items-center gap-1">
              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" />
              </svg>
            </div>
          </div>
          
          {/* Screen Content */}
          <div className="h-[calc(100%-2.5rem)] overflow-auto">
            {children}
          </div>
        </div>
        
        {/* Home Button for feature phones */}
        {isFeaturePhone && (
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-8 h-8 bg-gray-800 rounded-full"></div>
        )}
      </div>
    </div>
  );
}
