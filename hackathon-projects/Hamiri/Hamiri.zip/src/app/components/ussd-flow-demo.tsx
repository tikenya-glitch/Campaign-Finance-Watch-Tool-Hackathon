import React, { useState } from 'react';
import { MobileDevice } from './mobile-device';
import { USSDScreen } from './ussd-screen';
import { motion, AnimatePresence } from 'motion/react';

export function USSDFlowDemo() {
  const [currentStep, setCurrentStep] = useState<'initial' | 'language' | 'main-menu' | 'report-type' | 'location' | 'candidate' | 'amount' | 'evidence' | 'crowd' | 'confirmation'>('initial');
  const [selectedLanguage, setSelectedLanguage] = useState<'english' | 'kiswahili' | 'sheng'>('english');
  const [isPlaying, setIsPlaying] = useState(false);

  const steps: Array<{ step: 'initial' | 'language' | 'main-menu' | 'report-type' | 'location' | 'candidate' | 'amount' | 'evidence' | 'crowd' | 'confirmation'; delay: number }> = [
    { step: 'initial', delay: 0 },
    { step: 'main-menu', delay: 2000 },
    { step: 'report-type', delay: 4000 },
    { step: 'location', delay: 6000 },
    { step: 'candidate', delay: 8000 },
    { step: 'amount', delay: 10000 },
    { step: 'confirmation', delay: 12000 }
  ];

  const startDemo = () => {
    setIsPlaying(true);
    setCurrentStep('initial');
    
    steps.forEach(({ step, delay }) => {
      setTimeout(() => {
        setCurrentStep(step);
      }, delay);
    });

    setTimeout(() => {
      setIsPlaying(false);
    }, 14000);
  };

  return (
    <div className="w-full max-w-6xl mx-auto py-8">
      <h2 className="text-3xl font-bold text-center mb-4 text-gray-900">
        USSD Comprehensive Flow Demonstration
      </h2>
      <p className="text-center text-gray-600 mb-8 max-w-2xl mx-auto">
        See the complete reporting flow - from language selection to submission. Dial <strong style={{ color: '#ff3a21' }}>*384*96#</strong> - 
        works on any phone, no internet required, completely anonymous.
      </p>

      {/* Controls */}
      <div className="flex justify-center gap-4 mb-8">
        <button
          onClick={startDemo}
          disabled={isPlaying}
          className="px-6 py-3 rounded-lg font-semibold text-white shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          style={{ backgroundColor: '#ff3a21' }}
        >
          {isPlaying ? 'Playing Full Demo...' : '▶ Play Full Demo'}
        </button>
        
        <select
          value={selectedLanguage}
          onChange={(e) => setSelectedLanguage(e.target.value as any)}
          className="px-4 py-3 rounded-lg border-2 font-semibold"
          style={{ borderColor: '#0b65b1', color: '#0b65b1' }}
        >
          <option value="english">English</option>
          <option value="kiswahili">Kiswahili</option>
          <option value="sheng">Sheng</option>
        </select>
      </div>

      {/* Manual Step Controls */}
      <div className="flex justify-center gap-2 mb-8 flex-wrap">
        <button
          onClick={() => setCurrentStep('initial')}
          className={`px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
            currentStep === 'initial' 
              ? 'text-white shadow-lg' 
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
          style={currentStep === 'initial' ? { backgroundColor: '#ff3a21' } : {}}
        >
          1. Welcome
        </button>
        <button
          onClick={() => setCurrentStep('main-menu')}
          className={`px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
            currentStep === 'main-menu' 
              ? 'text-white shadow-lg' 
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
          style={currentStep === 'main-menu' ? { backgroundColor: '#0b65b1' } : {}}
        >
          2. Main Menu
        </button>
        <button
          onClick={() => setCurrentStep('report-type')}
          className={`px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
            currentStep === 'report-type' 
              ? 'text-white shadow-lg' 
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
          style={currentStep === 'report-type' ? { backgroundColor: '#ff3a21' } : {}}
        >
          3. Report Type
        </button>
        <button
          onClick={() => setCurrentStep('location')}
          className={`px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
            currentStep === 'location' 
              ? 'text-white shadow-lg' 
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
          style={currentStep === 'location' ? { backgroundColor: '#0b65b1' } : {}}
        >
          4. Location
        </button>
        <button
          onClick={() => setCurrentStep('candidate')}
          className={`px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
            currentStep === 'candidate' 
              ? 'text-white shadow-lg' 
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
          style={currentStep === 'candidate' ? { backgroundColor: '#ff3a21' } : {}}
        >
          5. Candidate
        </button>
        <button
          onClick={() => setCurrentStep('amount')}
          className={`px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
            currentStep === 'amount' 
              ? 'text-white shadow-lg' 
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
          style={currentStep === 'amount' ? { backgroundColor: '#0b65b1' } : {}}
        >
          6. Amount
        </button>
        <button
          onClick={() => setCurrentStep('confirmation')}
          className={`px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
            currentStep === 'confirmation' 
              ? 'text-white shadow-lg' 
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
          style={currentStep === 'confirmation' ? { backgroundColor: '#ff3a21' } : {}}
        >
          7. Confirm
        </button>
      </div>

      {/* Mobile Devices */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-start justify-items-center">
        {/* Feature Phone */}
        <div className="text-center">
          <h3 className="font-bold mb-4" style={{ color: '#ff3a21' }}>Feature Phone</h3>
          <motion.div
            key={`feature-${currentStep}`}
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <MobileDevice variant="feature">
              <USSDScreen step={currentStep} language={selectedLanguage} />
            </MobileDevice>
          </motion.div>
          <p className="mt-4 text-sm text-gray-600">Basic phones<br />No internet needed</p>
        </div>

        {/* Android Phone */}
        <div className="text-center">
          <h3 className="font-bold mb-4" style={{ color: '#0b65b1' }}>Android Phone</h3>
          <motion.div
            key={`android-${currentStep}`}
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <MobileDevice variant="android">
              <USSDScreen step={currentStep} language={selectedLanguage} />
            </MobileDevice>
          </motion.div>
          <p className="mt-4 text-sm text-gray-600">Smartphones<br />Same USSD experience</p>
        </div>

        {/* iOS Phone */}
        <div className="text-center">
          <h3 className="font-bold mb-4" style={{ color: '#ff3a21' }}>iOS Phone</h3>
          <motion.div
            key={`ios-${currentStep}`}
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <MobileDevice variant="ios">
              <USSDScreen step={currentStep} language={selectedLanguage} />
            </MobileDevice>
          </motion.div>
          <p className="mt-4 text-sm text-gray-600">iPhones<br />Universal access</p>
        </div>
      </div>

      {/* Step Explanation */}
      <div className="mt-12 bg-white rounded-xl shadow-lg p-6 border-l-4" style={{ borderLeftColor: '#0b65b1' }}>
        <h3 className="font-bold text-lg mb-4">Current Step: {currentStep.toUpperCase().replace(/-/g, ' ')}</h3>
        <div className="space-y-2 text-sm text-gray-700">
          {currentStep === 'initial' && (
            <>
              <p>• User dials <strong>*384*96#</strong> from any phone</p>
              <p>• System presents language options (English, Kiswahili, Sheng, Local)</p>
              <p>• No app download, no internet connection required</p>
              <p>• Works on all networks (Safaricom, Airtel, Telkom)</p>
            </>
          )}
          {currentStep === 'main-menu' && (
            <>
              <p>• Main menu with 4 options: Report, Trends, Rights, About</p>
              <p>• Most users select option 1 to report spending</p>
              <p>• Navigation is simple number-based selection</p>
              <p>• Can exit anytime by pressing 0</p>
            </>
          )}
          {currentStep === 'report-type' && (
            <>
              <p>• User selects the type of spending they witnessed</p>
              <p>• Options: Rally, Cash handouts, Transport, Posters, Food, Other</p>
              <p>• This categorizes the report for better analysis</p>
              <p>• Simple 1-6 selection for easy reporting</p>
            </>
          )}
          {currentStep === 'location' && (
            <>
              <p>• User selects their county from list or "Other"</p>
              <p>• Next screen asks for Ward Code or Ward Name</p>
              <p>• Location data enables ward-level aggregation</p>
              <p>• No GPS tracking - user manually selects area</p>
            </>
          )}
          {currentStep === 'candidate' && (
            <>
              <p>• User identifies who organized the spending</p>
              <p>• Options: Presidential, Governor, MP, MCA, Party, Not Sure</p>
              <p>• Next step allows typing candidate or party name</p>
              <p>• Links spending to specific candidates</p>
            </>
          )}
          {currentStep === 'amount' && (
            <>
              <p>• User estimates spending using simple ranges</p>
              <p>• Ranges: Below 10K, 10-50K, 50-200K, 200K-1M, Above 1M</p>
              <p>• No exact numbers needed - just rough estimate</p>
              <p>• Easy for citizens to select without calculation</p>
            </>
          )}
          {currentStep === 'confirmation' && (
            <>
              <p>• User receives confirmation that signal was recorded</p>
              <p>• Report ID provided for reference (e.g., 84721)</p>
              <p>• Options to submit another report, return to menu, or exit</p>
              <p>• Response is immediately processed and added to ward totals</p>
            </>
          )}
        </div>
      </div>

      {/* Backend Processing Info */}
      <div className="mt-8 bg-gradient-to-r from-[#ff3a21]/10 to-[#0b65b1]/10 rounded-xl p-6 border-2" style={{ borderColor: '#0b65b1' }}>
        <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
          <span className="text-xl">⚙️</span>
          What Happens Behind the Scenes
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-semibold mb-2 text-sm" style={{ color: '#ff3a21' }}>Data Captured:</h4>
            <ul className="text-sm space-y-1 text-gray-700">
              <li>✓ Report ID & Timestamp</li>
              <li>✓ County, Constituency, Ward</li>
              <li>✓ Spending Category & Amount Range</li>
              <li>✓ Candidate/Party Identification</li>
              <li>✓ Evidence Type & Crowd Size</li>
              <li>✓ Language Preference</li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-2 text-sm" style={{ color: '#0b65b1' }}>System Processing:</h4>
            <ul className="text-sm space-y-1 text-gray-700">
              <li>→ Aggregates reports by ward</li>
              <li>→ Estimates spending clusters</li>
              <li>→ Compares with IEBC declarations</li>
              <li>→ Visualizes discrepancies</li>
              <li>→ Flags mathematical impossibilities</li>
              <li>→ Updates dashboard in real-time</li>
            </ul>
          </div>
        </div>

        <div className="mt-4 bg-white rounded-lg p-4 border-l-4" style={{ borderLeftColor: '#ff3a21' }}>
          <p className="text-sm font-semibold mb-2">Example Output:</p>
          <div className="text-xs space-y-1 font-mono text-gray-700">
            <p>Ward: Kahawa West</p>
            <p>Declared Spending: KES 500,000</p>
            <p>Citizen Signals Estimate: KES 2.1M</p>
            <p className="font-bold" style={{ color: '#ff3a21' }}>Discrepancy: +320%</p>
          </div>
        </div>
      </div>
    </div>
  );
}