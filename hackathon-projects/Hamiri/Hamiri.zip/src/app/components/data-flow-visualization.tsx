import React from 'react';
import { motion } from 'motion/react';

export function DataFlowVisualization() {
  return (
    <div className="w-full h-full min-h-[600px] bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl p-8 relative overflow-hidden">
      {/* Animated Background Grid */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: 'linear-gradient(#0b65b1 1px, transparent 1px), linear-gradient(90deg, #0b65b1 1px, transparent 1px)',
          backgroundSize: '40px 40px'
        }}></div>
      </div>

      <div className="relative z-10">
        <h2 className="text-2xl font-bold text-center mb-12 text-gray-900">
          End-to-End Data Flow: From Citizen to Accountability
        </h2>

        {/* Flow Diagram */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-start">
          {/* Step 1: Citizen Input */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-center"
          >
            <div className="bg-white rounded-lg p-6 shadow-lg border-2 border-[#ff3a21]">
              <div className="w-16 h-16 bg-[#ff3a21] rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" />
                </svg>
              </div>
              <h3 className="font-bold text-sm mb-2" style={{ color: '#ff3a21' }}>CITIZEN</h3>
              <p className="text-xs text-gray-600 mb-3">
                Sends anonymous signal via USSD or WhatsApp
              </p>
              <div className="space-y-1 text-[10px] text-left bg-gray-50 p-2 rounded">
                <p>📱 *384*96# or</p>
                <p>💬 WhatsApp Bot</p>
                <p>🗣️ Local language</p>
                <p>🔒 Anonymous</p>
              </div>
            </div>
            
            {/* Arrow */}
            <motion.div
              className="hidden md:block absolute top-24 -right-8"
              animate={{ x: [0, 10, 0] }}
              transition={{ repeat: Infinity, duration: 2 }}
            >
              <svg className="w-16 h-8" viewBox="0 0 64 32" fill="none">
                <path d="M0 16 L50 16 M50 16 L42 8 M50 16 L42 24" stroke="#0b65b1" strokeWidth="2" />
              </svg>
            </motion.div>
          </motion.div>

          {/* Step 2: Data Aggregation */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-center"
          >
            <div className="bg-white rounded-lg p-6 shadow-lg border-2 border-[#0b65b1]">
              <div className="w-16 h-16 bg-[#0b65b1] rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M3 12v3c0 1.657 3.134 3 7 3s7-1.343 7-3v-3c0 1.657-3.134 3-7 3s-7-1.343-7-3z" />
                  <path d="M3 7v3c0 1.657 3.134 3 7 3s7-1.343 7-3V7c0 1.657-3.134 3-7 3S3 8.657 3 7z" />
                  <path d="M17 5c0 1.657-3.134 3-7 3S3 6.657 3 5s3.134-3 7-3 7 1.343 7 3z" />
                </svg>
              </div>
              <h3 className="font-bold text-sm mb-2" style={{ color: '#0b65b1' }}>AGGREGATION</h3>
              <p className="text-xs text-gray-600 mb-3">
                Ward-level signal collection & anonymization
              </p>
              <div className="space-y-1 text-[10px] text-left bg-gray-50 p-2 rounded">
                <p>📊 Group by ward</p>
                <p>🔐 Strip identity</p>
                <p>📈 Calculate totals</p>
                <p>⚡ Real-time processing</p>
              </div>
            </div>
            
            {/* Arrow */}
            <motion.div
              className="hidden md:block absolute top-24 -right-8"
              animate={{ x: [0, 10, 0] }}
              transition={{ repeat: Infinity, duration: 2, delay: 0.5 }}
            >
              <svg className="w-16 h-8" viewBox="0 0 64 32" fill="none">
                <path d="M0 16 L50 16 M50 16 L42 8 M50 16 L42 24" stroke="#ff3a21" strokeWidth="2" />
              </svg>
            </motion.div>
          </motion.div>

          {/* Step 3: Intelligence Analysis */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="text-center"
          >
            <div className="bg-white rounded-lg p-6 shadow-lg border-2 border-[#ff3a21]">
              <div className="w-16 h-16 bg-[#ff3a21] rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" />
                </svg>
              </div>
              <h3 className="font-bold text-sm mb-2" style={{ color: '#ff3a21' }}>ANALYSIS</h3>
              <p className="text-xs text-gray-600 mb-3">
                Cross-reference with IEBC declarations
              </p>
              <div className="space-y-1 text-[10px] text-left bg-gray-50 p-2 rounded">
                <p>🔍 Compare data sources</p>
                <p>🚨 Flag discrepancies</p>
                <p>📐 Math impossibilities</p>
                <p>🎯 Anomaly detection</p>
              </div>
            </div>
            
            {/* Arrow */}
            <motion.div
              className="hidden md:block absolute top-24 -right-8"
              animate={{ x: [0, 10, 0] }}
              transition={{ repeat: Infinity, duration: 2, delay: 1 }}
            >
              <svg className="w-16 h-8" viewBox="0 0 64 32" fill="none">
                <path d="M0 16 L50 16 M50 16 L42 8 M50 16 L42 24" stroke="#0b65b1" strokeWidth="2" />
              </svg>
            </motion.div>
          </motion.div>

          {/* Step 4: Public Output */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="text-center"
          >
            <div className="bg-white rounded-lg p-6 shadow-lg border-2 border-[#0b65b1]">
              <div className="w-16 h-16 bg-[#0b65b1] rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                  <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
                </svg>
              </div>
              <h3 className="font-bold text-sm mb-2" style={{ color: '#0b65b1' }}>ACCOUNTABILITY</h3>
              <p className="text-xs text-gray-600 mb-3">
                Public dashboard & reports
              </p>
              <div className="space-y-1 text-[10px] text-left bg-gray-50 p-2 rounded">
                <p>🗺️ Heat maps</p>
                <p>📰 Journalist reports</p>
                <p>🏛️ IEBC alerts</p>
                <p>👁️ Public visibility</p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Timeline at bottom */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="mt-12 text-center text-sm text-gray-600"
        >
          <div className="flex items-center justify-center gap-4">
            <span className="font-semibold" style={{ color: '#ff3a21' }}>⏱️ Real-time Processing</span>
            <span>→</span>
            <span className="font-semibold" style={{ color: '#0b65b1' }}>30 seconds average</span>
            <span>→</span>
            <span className="font-semibold" style={{ color: '#ff3a21' }}>Live updates every 15 minutes</span>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
