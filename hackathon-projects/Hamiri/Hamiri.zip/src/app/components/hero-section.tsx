import React from 'react';
import { motion } from 'motion/react';
import { TrendingUp, Users, Shield, AlertCircle } from 'lucide-react';

export function HeroSection() {
  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      {/* Animated Background */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0" style={{
          backgroundImage: `
            linear-gradient(to right, #ff3a21 1px, transparent 1px),
            linear-gradient(to bottom, #0b65b1 1px, transparent 1px)
          `,
          backgroundSize: '60px 60px'
        }}></div>
      </div>

      {/* Animated Particles */}
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 rounded-full"
          style={{
            backgroundColor: i % 2 === 0 ? '#ff3a21' : '#0b65b1',
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            y: [0, -30, 0],
            opacity: [0.3, 0.8, 0.3],
          }}
          transition={{
            duration: 3 + Math.random() * 2,
            repeat: Infinity,
            delay: Math.random() * 2,
          }}
        />
      ))}

      {/* Content */}
      <div className="relative z-10 max-w-6xl mx-auto px-6 py-20 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* Logo/Badge */}
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-lg px-6 py-3 rounded-full mb-8 border border-white/20">
            <span className="text-2xl">🇰🇪</span>
            <span className="text-white font-semibold">Campaign Finance Watch Tool</span>
          </div>

          {/* Main Heading */}
          <h1 className="text-5xl md:text-7xl font-bold mb-6">
            <span className="text-white">HAMIRI</span>{' '}
            <span className="bg-gradient-to-r from-[#ff3a21] to-[#0b65b1] bg-clip-text text-transparent">
              KE
            </span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto leading-relaxed">
            Tracking the gap between what candidates declare and what they actually spend
          </p>

          {/* Mission Statement */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 mb-12 border border-white/20 max-w-4xl mx-auto"
          >
            <p className="text-white text-lg leading-relaxed">
              A campaign finance watch platform that uses <strong style={{ color: '#ff3a21' }}>anonymous citizen signals</strong> collected 
              through WhatsApp and USSD — in Kiswahili, Sheng, and local languages — to visualize the gap between 
              what candidates declare and what they actually spend, turning thousands of private ward-level truths 
              into <strong style={{ color: '#0b65b1' }}>public financial accountability</strong> that candidates cannot declare away.
            </p>
          </motion.div>

          {/* Stats Grid */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12"
          >
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <div className="text-3xl mb-2" style={{ color: '#ff3a21' }}>📱</div>
              <div className="text-2xl font-bold text-white">USSD + WhatsApp</div>
              <div className="text-sm text-gray-400 mt-1">Data Collection</div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <div className="text-3xl mb-2" style={{ color: '#0b65b1' }}>🗺️</div>
              <div className="text-2xl font-bold text-white">47 Counties</div>
              <div className="text-sm text-gray-400 mt-1">Real-time Tracking</div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <div className="text-3xl mb-2" style={{ color: '#ff3a21' }}>🔒</div>
              <div className="text-2xl font-bold text-white">100% Anonymous</div>
              <div className="text-sm text-gray-400 mt-1">Zero PII Stored</div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 border border-white/20">
              <div className="text-3xl mb-2" style={{ color: '#0b65b1' }}>🌍</div>
              <div className="text-2xl font-bold text-white">3 Languages</div>
              <div className="text-sm text-gray-400 mt-1">Multi-lingual Access</div>
            </div>
          </motion.div>

          {/* Key Features Pills */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
            className="flex flex-wrap justify-center gap-3 mb-12"
          >
            <div className="bg-[#ff3a21]/20 backdrop-blur-lg px-6 py-3 rounded-full border border-[#ff3a21]/50 text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5" style={{ color: '#ff3a21' }} />
              <span>Real-time Analytics</span>
            </div>
            <div className="bg-[#0b65b1]/20 backdrop-blur-lg px-6 py-3 rounded-full border border-[#0b65b1]/50 text-white flex items-center gap-2">
              <Users className="w-5 h-5" style={{ color: '#0b65b1' }} />
              <span>Citizen-Powered</span>
            </div>
            <div className="bg-[#ff3a21]/20 backdrop-blur-lg px-6 py-3 rounded-full border border-[#ff3a21]/50 text-white flex items-center gap-2">
              <Shield className="w-5 h-5" style={{ color: '#ff3a21' }} />
              <span>Privacy First</span>
            </div>
            <div className="bg-[#0b65b1]/20 backdrop-blur-lg px-6 py-3 rounded-full border border-[#0b65b1]/50 text-white flex items-center gap-2">
              <AlertCircle className="w-5 h-5" style={{ color: '#0b65b1' }} />
              <span>Anomaly Detection</span>
            </div>
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.9 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <button 
              className="px-8 py-4 rounded-lg font-bold text-white shadow-2xl hover:shadow-[0_0_30px_rgba(255,58,33,0.5)] transition-all text-lg"
              style={{ backgroundColor: '#ff3a21' }}
            >
              Explore the Platform ↓
            </button>
            <button 
              className="px-8 py-4 rounded-lg font-bold text-white shadow-2xl hover:shadow-[0_0_30px_rgba(11,101,177,0.5)] transition-all text-lg border-2"
              style={{ borderColor: '#0b65b1', backgroundColor: 'transparent' }}
            >
              View Technical Docs →
            </button>
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 2 }}
      >
        <div className="text-white text-sm flex flex-col items-center gap-2">
          <span>Scroll to explore</span>
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </div>
      </motion.div>
    </div>
  );
}
