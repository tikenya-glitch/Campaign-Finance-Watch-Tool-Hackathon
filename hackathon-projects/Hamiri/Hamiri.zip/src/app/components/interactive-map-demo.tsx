import React, { useState } from 'react';
import { TrendingUp, TrendingDown, AlertTriangle, Activity, Target, Calculator, BarChart3, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CountyData {
  name: string;
  intensity: 'low' | 'medium' | 'high' | 'critical';
  declared: number;
  estimated: number;
  gap: number;
  signals: number;
  wards: number;
  weeklyTrend: number[];
  anomalyScore: number;
  benchmarkViolations: string[];
}

const mockCountyData: CountyData[] = [
  { 
    name: 'Nairobi', 
    intensity: 'critical', 
    declared: 50000000, 
    estimated: 156000000, 
    gap: 212, 
    signals: 1247,
    wards: 17,
    weeklyTrend: [45, 67, 89, 134, 178, 212],
    anomalyScore: 9.4,
    benchmarkViolations: ['Mathematical impossibility', 'Velocity spike', 'Ward cluster anomaly']
  },
  { 
    name: 'Kiambu', 
    intensity: 'high', 
    declared: 35000000, 
    estimated: 89000000, 
    gap: 154, 
    signals: 892,
    wards: 12,
    weeklyTrend: [32, 56, 78, 98, 134, 154],
    anomalyScore: 7.8,
    benchmarkViolations: ['IEBC cap exceeded', 'Velocity spike']
  },
  { 
    name: 'Mombasa', 
    intensity: 'medium', 
    declared: 28000000, 
    estimated: 52000000, 
    gap: 86, 
    signals: 643,
    wards: 6,
    weeklyTrend: [12, 23, 45, 58, 72, 86],
    anomalyScore: 5.2,
    benchmarkViolations: ['Pattern inconsistency']
  },
  { 
    name: 'Nakuru', 
    intensity: 'high', 
    declared: 32000000, 
    estimated: 78000000, 
    gap: 144, 
    signals: 734,
    wards: 11,
    weeklyTrend: [28, 45, 67, 89, 112, 144],
    anomalyScore: 7.3,
    benchmarkViolations: ['Mathematical impossibility', 'Ward cluster anomaly']
  },
  { 
    name: 'Kisumu', 
    intensity: 'medium', 
    declared: 24000000, 
    estimated: 45000000, 
    gap: 88, 
    signals: 521,
    wards: 7,
    weeklyTrend: [15, 28, 42, 56, 71, 88],
    anomalyScore: 4.9,
    benchmarkViolations: ['Pattern inconsistency']
  },
  { 
    name: 'Machakos', 
    intensity: 'low', 
    declared: 18000000, 
    estimated: 26000000, 
    gap: 44, 
    signals: 387,
    wards: 8,
    weeklyTrend: [12, 18, 24, 32, 38, 44],
    anomalyScore: 2.8,
    benchmarkViolations: []
  },
  { 
    name: 'Kakamega', 
    intensity: 'medium', 
    declared: 26000000, 
    estimated: 51000000, 
    gap: 96, 
    signals: 612,
    wards: 12,
    weeklyTrend: [18, 32, 48, 64, 80, 96],
    anomalyScore: 5.7,
    benchmarkViolations: ['Velocity spike']
  },
  { 
    name: 'Uasin Gishu', 
    intensity: 'high', 
    declared: 29000000, 
    estimated: 74000000, 
    gap: 155, 
    signals: 698,
    wards: 6,
    weeklyTrend: [25, 48, 72, 98, 126, 155],
    anomalyScore: 7.9,
    benchmarkViolations: ['Mathematical impossibility', 'Velocity spike']
  }
];

const benchmarkCriteria = [
  {
    name: 'Mathematical Impossibility',
    description: 'Ground signals suggest spending that cannot be achieved with declared budget',
    formula: 'If (Estimated Ward Spend × Weeks Remaining) > Declared Total Budget',
    threshold: 'Critical when >150% gap',
    color: '#ff3a21'
  },
  {
    name: 'Velocity Spike Detection',
    description: 'Sudden increase in spending rate compared to previous weeks',
    formula: 'Week-on-week growth rate > 50% for 2 consecutive weeks',
    threshold: 'High risk when >80% increase',
    color: '#ff6b4a'
  },
  {
    name: 'IEBC Legal Cap Violation',
    description: 'Estimated spending exceeds legal limits set by election body',
    formula: 'If Estimated Total > IEBC Legal Maximum',
    threshold: 'Immediate flag at any violation',
    color: '#ff3a21'
  },
  {
    name: 'Ward Cluster Anomaly',
    description: 'Specific wards show patterns inconsistent with county average',
    formula: 'Ward signal density > (County Average × 2.5)',
    threshold: 'Medium risk at 2x, High at 2.5x',
    color: '#ffa500'
  },
  {
    name: 'Pattern Inconsistency',
    description: 'Spending pattern doesn\'t match typical campaign arc',
    formula: 'Statistical deviation from expected pre-election curve',
    threshold: 'Medium risk at >1.5 standard deviations',
    color: '#0b65b1'
  }
];

export function InteractiveMapDemo() {
  const [selectedCounty, setSelectedCounty] = useState<CountyData | null>(mockCountyData[0]);
  const [filterIntensity, setFilterIntensity] = useState<string>('all');
  const [activePanel, setActivePanel] = useState<'overview' | 'benchmarks' | 'trends'>('overview');
  const [showRealTime, setShowRealTime] = useState(true);

  const getIntensityColor = (intensity: string) => {
    switch (intensity) {
      case 'critical': return '#ff3a21';
      case 'high': return '#ff6b4a';
      case 'medium': return '#ffa500';
      case 'low': return '#0b65b1';
      default: return '#gray';
    }
  };

  const formatCurrency = (amount: number) => {
    return `KSh ${(amount / 1000000).toFixed(1)}M`;
  };

  const filteredData = filterIntensity === 'all' 
    ? mockCountyData 
    : mockCountyData.filter(c => c.intensity === filterIntensity);

  return (
    <div className="w-full max-w-7xl mx-auto py-8">
      <h2 className="text-3xl font-bold text-center mb-4 text-gray-900">
        Interactive Anomaly Detection Dashboard
      </h2>
      <p className="text-center text-gray-600 mb-8 max-w-3xl mx-auto">
        Real-time heat map showing the gap between declared campaign spending and ground-level signals across Kenya.
        Our benchmark algorithms detect mathematical impossibilities, velocity spikes, and pattern anomalies.
      </p>

      {/* Real-time indicator */}
      <div className="flex justify-center mb-6">
        <div className="bg-white rounded-full shadow-lg px-6 py-3 flex items-center gap-3 border-2" style={{ borderColor: showRealTime ? '#0b65b1' : '#gray' }}>
          <motion.div
            animate={{ scale: showRealTime ? [1, 1.2, 1] : 1 }}
            transition={{ repeat: Infinity, duration: 2 }}
            className="w-3 h-3 rounded-full"
            style={{ backgroundColor: showRealTime ? '#0b65b1' : '#gray' }}
          />
          <span className="font-semibold text-sm">
            {showRealTime ? 'LIVE - Updates every 15 minutes' : 'Paused'}
          </span>
          <button
            onClick={() => setShowRealTime(!showRealTime)}
            className="ml-2 px-3 py-1 rounded-full text-xs font-semibold text-white"
            style={{ backgroundColor: '#0b65b1' }}
          >
            {showRealTime ? 'Pause' : 'Resume'}
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex justify-center gap-3 mb-8 flex-wrap">
        <button
          onClick={() => setFilterIntensity('all')}
          className={`px-5 py-3 rounded-lg font-semibold transition-all shadow-md ${
            filterIntensity === 'all' 
              ? 'text-white shadow-lg scale-105' 
              : 'bg-white text-gray-700 hover:bg-gray-50'
          }`}
          style={filterIntensity === 'all' ? { backgroundColor: '#0b65b1' } : {}}
        >
          All Counties ({mockCountyData.length})
        </button>
        <button
          onClick={() => setFilterIntensity('critical')}
          className={`px-5 py-3 rounded-lg font-semibold transition-all shadow-md ${
            filterIntensity === 'critical' 
              ? 'text-white shadow-lg scale-105' 
              : 'bg-red-50 text-red-700 hover:bg-red-100'
          }`}
          style={filterIntensity === 'critical' ? { backgroundColor: '#ff3a21' } : {}}
        >
          🚨 Critical ({mockCountyData.filter(c => c.intensity === 'critical').length})
        </button>
        <button
          onClick={() => setFilterIntensity('high')}
          className={`px-5 py-3 rounded-lg font-semibold transition-all shadow-md ${
            filterIntensity === 'high' 
              ? 'text-white shadow-lg scale-105' 
              : 'bg-orange-50 text-orange-700 hover:bg-orange-100'
          }`}
          style={filterIntensity === 'high' ? { backgroundColor: '#ff6b4a' } : {}}
        >
          ⚠️ High Risk ({mockCountyData.filter(c => c.intensity === 'high').length})
        </button>
        <button
          onClick={() => setFilterIntensity('medium')}
          className={`px-5 py-3 rounded-lg font-semibold transition-all shadow-md ${
            filterIntensity === 'medium' 
              ? 'text-white shadow-lg scale-105' 
              : 'bg-yellow-50 text-yellow-700 hover:bg-yellow-100'
          }`}
          style={filterIntensity === 'medium' ? { backgroundColor: '#ffa500' } : {}}
        >
          ⚡ Medium ({mockCountyData.filter(c => c.intensity === 'medium').length})
        </button>
        <button
          onClick={() => setFilterIntensity('low')}
          className={`px-5 py-3 rounded-lg font-semibold transition-all shadow-md ${
            filterIntensity === 'low' 
              ? 'text-white shadow-lg scale-105' 
              : 'bg-blue-50 text-blue-700 hover:bg-blue-100'
          }`}
          style={filterIntensity === 'low' ? { backgroundColor: '#0b65b1' } : {}}
        >
          ✓ Low ({mockCountyData.filter(c => c.intensity === 'low').length})
        </button>
      </div>

      {/* Main Dashboard Panel */}
      <div className="bg-white rounded-2xl shadow-2xl overflow-hidden border" style={{ borderColor: '#e5e7eb' }}>
        {/* Dashboard Header */}
        <div className="bg-gradient-to-r from-[#ff3a21] to-[#0b65b1] p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-2xl font-bold mb-1">Kenya Campaign Finance Heat Map</h3>
              <p className="text-sm opacity-90">Week 6 of 12 - Pre-Election Monitoring</p>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold">{filteredData.length}</div>
              <div className="text-sm opacity-90">Counties Active</div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-0">
          {/* Map Area */}
          <div className="lg:col-span-2 p-6 border-r border-gray-200">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="font-bold text-lg flex items-center gap-2">
                <span className="text-xl">🗺️</span>
                County Heat Map
              </h3>
              <div className="flex gap-2">
                <span className="text-xs bg-gray-100 px-3 py-1 rounded-full font-semibold text-gray-700">
                  {filteredData.reduce((sum, c) => sum + c.signals, 0).toLocaleString()} Signals
                </span>
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl p-6 min-h-[500px] relative border-2 border-gray-200">
              {/* Map Grid */}
              <div className="grid grid-cols-2 gap-4">
                {filteredData.map((county) => (
                  <motion.button
                    key={county.name}
                    onClick={() => setSelectedCounty(county)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.98 }}
                    className="relative p-5 rounded-xl shadow-lg hover:shadow-2xl transition-all cursor-pointer border-3 bg-white"
                    style={{
                      borderColor: selectedCounty?.name === county.name 
                        ? getIntensityColor(county.intensity)
                        : 'transparent',
                      borderWidth: selectedCounty?.name === county.name ? '3px' : '1px'
                    }}
                  >
                    {/* Intensity Background */}
                    <div 
                      className="absolute inset-0 rounded-xl opacity-20"
                      style={{ backgroundColor: getIntensityColor(county.intensity) }}
                    />
                    
                    <div className="relative">
                      <div className="flex items-start justify-between mb-3">
                        <h4 className="font-bold text-base text-left">{county.name}</h4>
                        {county.intensity === 'critical' && (
                          <motion.div
                            animate={{ rotate: [0, 10, -10, 0] }}
                            transition={{ repeat: Infinity, duration: 1 }}
                          >
                            <AlertTriangle className="w-5 h-5" style={{ color: '#ff3a21' }} />
                          </motion.div>
                        )}
                      </div>
                      
                      <div className="space-y-2 text-left">
                        {/* Anomaly Score */}
                        <div className="bg-white/80 rounded-lg p-2 border">
                          <div className="text-[10px] text-gray-600 mb-1">Anomaly Score</div>
                          <div className="flex items-center gap-2">
                            <div className="flex-1 bg-gray-200 rounded-full h-2">
                              <motion.div
                                initial={{ width: 0 }}
                                animate={{ width: `${(county.anomalyScore / 10) * 100}%` }}
                                transition={{ duration: 1, delay: 0.2 }}
                                className="h-2 rounded-full"
                                style={{ backgroundColor: getIntensityColor(county.intensity) }}
                              />
                            </div>
                            <span className="text-xs font-bold" style={{ color: getIntensityColor(county.intensity) }}>
                              {county.anomalyScore}/10
                            </span>
                          </div>
                        </div>
                        
                        {/* Gap Percentage */}
                        <div className="flex justify-between items-center bg-white/80 rounded-lg p-2 border">
                          <span className="text-[10px] text-gray-600">Declaration Gap:</span>
                          <span className="text-sm font-bold" style={{ color: getIntensityColor(county.intensity) }}>
                            +{county.gap}%
                          </span>
                        </div>
                        
                        {/* Signals */}
                        <div className="flex justify-between items-center bg-white/80 rounded-lg p-2 border">
                          <span className="text-[10px] text-gray-600">Citizen Signals:</span>
                          <span className="text-sm font-semibold">{county.signals}</span>
                        </div>

                        {/* Wards */}
                        <div className="flex justify-between items-center bg-white/80 rounded-lg p-2 border">
                          <span className="text-[10px] text-gray-600">Active Wards:</span>
                          <span className="text-sm font-semibold">{county.wards}</span>
                        </div>
                      </div>
                    </div>
                  </motion.button>
                ))}
              </div>

              {/* Legend */}
              <div className="absolute bottom-6 left-6 bg-white rounded-xl shadow-xl p-4 border-2 border-gray-200">
                <h4 className="font-bold text-xs mb-3 flex items-center gap-2">
                  <Activity className="w-4 h-4" />
                  Intensity Scale
                </h4>
                <div className="space-y-2 text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-md border-2 flex items-center justify-center" style={{ backgroundColor: '#ff3a21', borderColor: '#ff3a21' }}>
                      <span className="text-white text-[10px] font-bold">🚨</span>
                    </div>
                    <span className="font-semibold">Critical - &gt;150% gap</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-md border-2" style={{ backgroundColor: '#ff6b4a', borderColor: '#ff6b4a' }}></div>
                    <span>High - 100-150% gap</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-md border-2" style={{ backgroundColor: '#ffa500', borderColor: '#ffa500' }}></div>
                    <span>Medium - 50-100% gap</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-md border-2" style={{ backgroundColor: '#0b65b1', borderColor: '#0b65b1' }}></div>
                    <span>Low - &lt;50% gap</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Details Panel */}
          <div className="p-6 bg-gray-50">
            {/* Panel Tabs */}
            <div className="flex gap-2 mb-4">
              <button
                onClick={() => setActivePanel('overview')}
                className={`flex-1 px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
                  activePanel === 'overview'
                    ? 'text-white shadow-lg'
                    : 'bg-white text-gray-600 hover:bg-gray-100'
                }`}
                style={activePanel === 'overview' ? { backgroundColor: '#ff3a21' } : {}}
              >
                Overview
              </button>
              <button
                onClick={() => setActivePanel('benchmarks')}
                className={`flex-1 px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
                  activePanel === 'benchmarks'
                    ? 'text-white shadow-lg'
                    : 'bg-white text-gray-600 hover:bg-gray-100'
                }`}
                style={activePanel === 'benchmarks' ? { backgroundColor: '#0b65b1' } : {}}
              >
                Benchmarks
              </button>
              <button
                onClick={() => setActivePanel('trends')}
                className={`flex-1 px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
                  activePanel === 'trends'
                    ? 'text-white shadow-lg'
                    : 'bg-white text-gray-600 hover:bg-gray-100'
                }`}
                style={activePanel === 'trends' ? { backgroundColor: '#ff3a21' } : {}}
              >
                Trends
              </button>
            </div>

            <AnimatePresence mode="wait">
              {selectedCounty ? (
                <motion.div
                  key={`${selectedCounty.name}-${activePanel}`}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-4"
                >
                  {/* County Header */}
                  <div className="bg-white rounded-xl p-4 border-2 shadow-lg" style={{ borderColor: getIntensityColor(selectedCounty.intensity) }}>
                    <h4 className="font-bold text-xl mb-2">{selectedCounty.name} County</h4>
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-white text-xs font-bold"
                      style={{ backgroundColor: getIntensityColor(selectedCounty.intensity) }}>
                      {selectedCounty.intensity === 'critical' && <AlertTriangle className="w-3 h-3" />}
                      {selectedCounty.intensity.toUpperCase()} RISK
                    </div>
                  </div>

                  {/* Panel Content */}
                  {activePanel === 'overview' && (
                    <div className="space-y-3">
                      {/* Anomaly Score Card */}
                      <div className="bg-white rounded-xl p-4 shadow-lg border">
                        <div className="flex items-center gap-2 mb-3">
                          <Target className="w-5 h-5" style={{ color: '#ff3a21' }} />
                          <span className="font-bold text-sm">Anomaly Score</span>
                        </div>
                        <div className="text-4xl font-bold mb-2" style={{ color: getIntensityColor(selectedCounty.intensity) }}>
                          {selectedCounty.anomalyScore}/10
                        </div>
                        <div className="bg-gray-100 rounded-full h-3 mb-2">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${(selectedCounty.anomalyScore / 10) * 100}%` }}
                            className="h-3 rounded-full"
                            style={{ backgroundColor: getIntensityColor(selectedCounty.intensity) }}
                          />
                        </div>
                        <p className="text-xs text-gray-600">Based on 5 benchmark criteria violations</p>
                      </div>

                      {/* Declared vs Estimated */}
                      <div className="bg-white rounded-xl p-4 shadow-lg border">
                        <div className="text-xs text-gray-600 mb-2">Declared Campaign Budget</div>
                        <div className="text-2xl font-bold mb-3" style={{ color: '#0b65b1' }}>
                          {formatCurrency(selectedCounty.declared)}
                        </div>
                        
                        <div className="border-t pt-3">
                          <div className="text-xs text-gray-600 mb-2">Estimated Actual Spending</div>
                          <div className="text-2xl font-bold mb-2" style={{ color: '#ff3a21' }}>
                            {formatCurrency(selectedCounty.estimated)}
                          </div>
                        </div>

                        <div className="bg-red-50 rounded-lg p-3 mt-3 border border-red-200">
                          <div className="flex items-center gap-2 mb-1">
                            <TrendingUp className="w-5 h-5" style={{ color: '#ff3a21' }} />
                            <span className="text-sm font-bold" style={{ color: '#ff3a21' }}>
                              +{selectedCounty.gap}% Gap Detected
                            </span>
                          </div>
                          <p className="text-xs text-gray-700">
                            Undeclared: {formatCurrency(selectedCounty.estimated - selectedCounty.declared)}
                          </p>
                        </div>
                      </div>

                      {/* Signals Card */}
                      <div className="bg-white rounded-xl p-4 shadow-lg border">
                        <div className="text-xs text-gray-600 mb-2">Citizen Signals This Week</div>
                        <div className="text-3xl font-bold mb-2 text-gray-900">
                          {selectedCounty.signals.toLocaleString()}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-gray-600">
                          <span>From {selectedCounty.wards} wards</span>
                          <span>•</span>
                          <span>Avg {Math.floor(selectedCounty.signals / selectedCounty.wards)} per ward</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {activePanel === 'benchmarks' && (
                    <div className="space-y-3 max-h-[600px] overflow-y-auto">
                      <div className="bg-white rounded-xl p-4 shadow-lg border">
                        <div className="flex items-center gap-2 mb-3">
                          <Calculator className="w-5 h-5" style={{ color: '#0b65b1' }} />
                          <span className="font-bold text-sm">Benchmark Violations</span>
                        </div>
                        
                        {selectedCounty.benchmarkViolations.length > 0 ? (
                          <div className="space-y-2">
                            {selectedCounty.benchmarkViolations.map((violation, idx) => (
                              <div key={idx} className="bg-red-50 border-l-4 border-red-500 p-3 rounded">
                                <div className="flex items-start gap-2">
                                  <AlertTriangle className="w-4 h-4 mt-0.5" style={{ color: '#ff3a21' }} />
                                  <div>
                                    <p className="font-bold text-sm text-gray-900">{violation}</p>
                                    <p className="text-xs text-gray-600 mt-1">
                                      {benchmarkCriteria.find(b => b.name === violation)?.description}
                                    </p>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="bg-green-50 border-l-4 border-green-500 p-3 rounded">
                            <p className="text-sm text-green-800">✓ No benchmark violations detected</p>
                          </div>
                        )}
                      </div>

                      {/* Benchmark Methodology */}
                      <div className="bg-gradient-to-br from-[#0b65b1]/10 to-[#0b65b1]/5 rounded-xl p-4 border-2" style={{ borderColor: '#0b65b1' }}>
                        <h5 className="font-bold text-sm mb-3" style={{ color: '#0b65b1' }}>
                          How We Calculate Anomalies
                        </h5>
                        <div className="space-y-2 text-xs">
                          <div className="bg-white rounded-lg p-2">
                            <strong>Step 1:</strong> Aggregate ward-level citizen signals
                          </div>
                          <div className="bg-white rounded-lg p-2">
                            <strong>Step 2:</strong> Cross-reference with IEBC declarations
                          </div>
                          <div className="bg-white rounded-lg p-2">
                            <strong>Step 3:</strong> Apply 5 benchmark algorithms
                          </div>
                          <div className="bg-white rounded-lg p-2">
                            <strong>Step 4:</strong> Calculate anomaly score (0-10)
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {activePanel === 'trends' && (
                    <div className="space-y-3">
                      {/* Weekly Trend Chart */}
                      <div className="bg-white rounded-xl p-4 shadow-lg border">
                        <div className="flex items-center gap-2 mb-3">
                          <BarChart3 className="w-5 h-5" style={{ color: '#ff3a21' }} />
                          <span className="font-bold text-sm">6-Week Gap Trend</span>
                        </div>
                        
                        <div className="space-y-2">
                          {selectedCounty.weeklyTrend.map((value, idx) => (
                            <div key={idx} className="flex items-center gap-2">
                              <span className="text-xs text-gray-600 w-12">Week {idx + 1}</span>
                              <div className="flex-1 bg-gray-100 rounded-full h-6 relative overflow-hidden">
                                <motion.div
                                  initial={{ width: 0 }}
                                  animate={{ width: `${(value / Math.max(...selectedCounty.weeklyTrend)) * 100}%` }}
                                  transition={{ duration: 0.5, delay: idx * 0.1 }}
                                  className="h-6 rounded-full flex items-center justify-end pr-2"
                                  style={{ 
                                    backgroundColor: value > 100 ? '#ff3a21' : value > 50 ? '#ffa500' : '#0b65b1'
                                  }}
                                >
                                  <span className="text-xs font-bold text-white">{value}%</span>
                                </motion.div>
                              </div>
                            </div>
                          ))}
                        </div>

                        <div className="mt-4 bg-yellow-50 rounded-lg p-3 border border-yellow-200">
                          <p className="text-xs text-gray-700">
                            <strong style={{ color: '#ff3a21' }}>↗ Acceleration detected:</strong> Gap increased by{' '}
                            {selectedCounty.weeklyTrend[selectedCounty.weeklyTrend.length - 1] - selectedCounty.weeklyTrend[0]}% over 6 weeks
                          </p>
                        </div>
                      </div>

                      {/* Projection */}
                      <div className="bg-white rounded-xl p-4 shadow-lg border">
                        <div className="flex items-center gap-2 mb-3">
                          <Clock className="w-5 h-5" style={{ color: '#0b65b1' }} />
                          <span className="font-bold text-sm">6-Week Projection</span>
                        </div>
                        
                        <div className="text-2xl font-bold mb-2" style={{ color: '#ff3a21' }}>
                          {formatCurrency(selectedCounty.estimated * 2)}
                        </div>
                        <p className="text-xs text-gray-600">
                          If current trend continues, estimated total by election day
                        </p>
                        
                        <div className="mt-3 bg-red-50 rounded-lg p-2 border border-red-200">
                          <p className="text-xs font-semibold" style={{ color: '#ff3a21' }}>
                            {Math.round((selectedCounty.estimated * 2 - selectedCounty.declared) / selectedCounty.declared * 100)}% over declared budget
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="pt-4 space-y-2">
                    <button className="w-full px-4 py-3 rounded-lg text-white font-semibold text-sm shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
                      style={{ backgroundColor: '#ff3a21' }}>
                      <span>📊</span> View Ward Breakdown
                    </button>
                    <button className="w-full px-4 py-3 rounded-lg text-white font-semibold text-sm shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
                      style={{ backgroundColor: '#0b65b1' }}>
                      <span>📥</span> Download Full Report (PDF)
                    </button>
                  </div>
                </motion.div>
              ) : (
                <div className="bg-white rounded-xl p-8 text-center border-2 border-dashed border-gray-300 min-h-[400px] flex items-center justify-center">
                  <div>
                    <div className="text-4xl mb-3">👆</div>
                    <p className="text-gray-600 font-semibold">Select a county on the map</p>
                    <p className="text-sm text-gray-500 mt-2">to view detailed analysis</p>
                  </div>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Benchmark Methodology Section */}
      <div className="mt-12 bg-white rounded-2xl shadow-2xl p-8 border">
        <h3 className="text-2xl font-bold mb-6 text-center flex items-center justify-center gap-3">
          <Calculator className="w-7 h-7" style={{ color: '#0b65b1' }} />
          <span>Anomaly Detection Benchmarks</span>
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {benchmarkCriteria.map((benchmark, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-gradient-to-br from-gray-50 to-white rounded-xl p-6 border-l-4 shadow-lg hover:shadow-xl transition-all"
              style={{ borderLeftColor: benchmark.color }}
            >
              <div className="flex items-start gap-3 mb-3">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold text-sm"
                  style={{ backgroundColor: benchmark.color }}>
                  {idx + 1}
                </div>
                <div>
                  <h4 className="font-bold text-base mb-1" style={{ color: benchmark.color }}>
                    {benchmark.name}
                  </h4>
                  <p className="text-sm text-gray-600">{benchmark.description}</p>
                </div>
              </div>
              
              <div className="bg-white rounded-lg p-3 mb-3 border">
                <div className="text-xs text-gray-600 mb-1">Formula:</div>
                <code className="text-xs font-mono" style={{ color: '#0b65b1' }}>
                  {benchmark.formula}
                </code>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-3 border">
                <div className="text-xs text-gray-600 mb-1">Threshold:</div>
                <p className="text-xs font-semibold text-gray-900">{benchmark.threshold}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* How Scoring Works */}
        <div className="mt-8 bg-gradient-to-r from-[#ff3a21]/10 to-[#0b65b1]/10 rounded-xl p-6 border-2" style={{ borderColor: '#0b65b1' }}>
          <h4 className="font-bold text-lg mb-4 flex items-center gap-2">
            <Target className="w-5 h-5" style={{ color: '#ff3a21' }} />
            How Anomaly Scores are Calculated
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
            <div className="bg-white rounded-lg p-4 text-center shadow">
              <div className="text-2xl font-bold mb-1" style={{ color: '#0b65b1' }}>0-2.5</div>
              <div className="text-xs text-gray-600">Low Risk</div>
              <div className="text-xs mt-2">Normal variance</div>
            </div>
            <div className="bg-white rounded-lg p-4 text-center shadow">
              <div className="text-2xl font-bold mb-1" style={{ color: '#ffa500' }}>2.5-5.0</div>
              <div className="text-xs text-gray-600">Medium Risk</div>
              <div className="text-xs mt-2">Monitor closely</div>
            </div>
            <div className="bg-white rounded-lg p-4 text-center shadow">
              <div className="text-2xl font-bold mb-1" style={{ color: '#ff6b4a' }}>5.0-7.5</div>
              <div className="text-xs text-gray-600">High Risk</div>
              <div className="text-xs mt-2">Investigation needed</div>
            </div>
            <div className="bg-white rounded-lg p-4 text-center shadow">
              <div className="text-2xl font-bold mb-1" style={{ color: '#ff3a21' }}>7.5-10</div>
              <div className="text-xs text-gray-600">Critical</div>
              <div className="text-xs mt-2">Immediate action</div>
            </div>
          </div>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-lg p-6 border-l-4" style={{ borderLeftColor: '#ff3a21' }}>
          <h4 className="text-xs text-gray-600 mb-2 uppercase">Total Declared</h4>
          <p className="text-3xl font-bold" style={{ color: '#ff3a21' }}>
            {formatCurrency(mockCountyData.reduce((sum, c) => sum + c.declared, 0))}
          </p>
          <p className="text-xs text-gray-500 mt-1">All counties combined</p>
        </div>
        
        <div className="bg-white rounded-xl shadow-lg p-6 border-l-4" style={{ borderLeftColor: '#0b65b1' }}>
          <h4 className="text-xs text-gray-600 mb-2 uppercase">Estimated Actual</h4>
          <p className="text-3xl font-bold" style={{ color: '#0b65b1' }}>
            {formatCurrency(mockCountyData.reduce((sum, c) => sum + c.estimated, 0))}
          </p>
          <p className="text-xs text-gray-500 mt-1">Based on ground signals</p>
        </div>
        
        <div className="bg-white rounded-xl shadow-lg p-6 border-l-4" style={{ borderLeftColor: '#ff3a21' }}>
          <h4 className="text-xs text-gray-600 mb-2 uppercase">Total Gap</h4>
          <p className="text-3xl font-bold text-gray-900">
            {formatCurrency(
              mockCountyData.reduce((sum, c) => sum + c.estimated, 0) - 
              mockCountyData.reduce((sum, c) => sum + c.declared, 0)
            )}
          </p>
          <p className="text-xs text-gray-500 mt-1">Potential undeclared</p>
        </div>
        
        <div className="bg-white rounded-xl shadow-lg p-6 border-l-4" style={{ borderLeftColor: '#0b65b1' }}>
          <h4 className="text-xs text-gray-600 mb-2 uppercase">Citizen Signals</h4>
          <p className="text-3xl font-bold text-gray-900">
            {mockCountyData.reduce((sum, c) => sum + c.signals, 0).toLocaleString()}
          </p>
          <p className="text-xs text-gray-500 mt-1">This week across Kenya</p>
        </div>
      </div>
    </div>
  );
}
