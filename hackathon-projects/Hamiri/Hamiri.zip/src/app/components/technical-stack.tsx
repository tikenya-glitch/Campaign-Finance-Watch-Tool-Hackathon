import React from 'react';
import { Code, Database, Cloud, Lock, Zap, Globe } from 'lucide-react';

interface TechStackItemProps {
  icon: React.ReactNode;
  title: string;
  technologies: { name: string; purpose: string }[];
  color: string;
}

function TechStackItem({ icon, title, technologies, color }: TechStackItemProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 border-l-4" style={{ borderLeftColor: color }}>
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2 rounded-lg" style={{ backgroundColor: `${color}20`, color }}>
          {icon}
        </div>
        <h3 className="font-bold text-lg">{title}</h3>
      </div>
      <div className="space-y-3">
        {technologies.map((tech, idx) => (
          <div key={idx} className="border-l-2 pl-3" style={{ borderLeftColor: `${color}40` }}>
            <p className="font-semibold text-sm" style={{ color }}>{tech.name}</p>
            <p className="text-xs text-gray-600">{tech.purpose}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export function TechnicalStack() {
  return (
    <div className="w-full max-w-6xl mx-auto py-8">
      <h2 className="text-3xl font-bold text-center mb-12 text-gray-900">
        Technical Architecture & Stack
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Data Collection Layer */}
        <TechStackItem
          icon={<Globe className="w-6 h-6" />}
          title="Data Collection"
          color="#ff3a21"
          technologies={[
            { 
              name: 'Africa\'s Talking API', 
              purpose: 'USSD gateway & SMS handling for feature phones (*384*96#)' 
            },
            { 
              name: 'WhatsApp Business API', 
              purpose: 'Conversational bot interface with natural language processing' 
            },
            { 
              name: 'Twilio Programmable SMS', 
              purpose: 'Backup SMS collection channel for redundancy' 
            },
            { 
              name: 'Multi-language NLP', 
              purpose: 'Kiswahili, Sheng, English processing with dialect support' 
            }
          ]}
        />

        {/* Backend Infrastructure */}
        <TechStackItem
          icon={<Database className="w-6 h-6" />}
          title="Backend & Database"
          color="#0b65b1"
          technologies={[
            { 
              name: 'Node.js + Express', 
              purpose: 'API server handling real-time signal ingestion' 
            },
            { 
              name: 'PostgreSQL + PostGIS', 
              purpose: 'Ward-level geospatial data storage & queries' 
            },
            { 
              name: 'Redis Cache', 
              purpose: 'Real-time aggregation & session management' 
            },
            { 
              name: 'TimescaleDB', 
              purpose: 'Time-series data for trend analysis' 
            }
          ]}
        />

        {/* Cloud Infrastructure */}
        <TechStackItem
          icon={<Cloud className="w-6 h-6" />}
          title="Cloud & Hosting"
          color="#ff3a21"
          technologies={[
            { 
              name: 'AWS EC2 / Digital Ocean', 
              purpose: 'Scalable compute instances in Kenya/Africa regions' 
            },
            { 
              name: 'AWS S3', 
              purpose: 'Data lake for raw signals & archival' 
            },
            { 
              name: 'CloudFlare CDN', 
              purpose: 'Fast global delivery & DDoS protection' 
            },
            { 
              name: 'Docker + Kubernetes', 
              purpose: 'Container orchestration for microservices' 
            }
          ]}
        />

        {/* Analytics & Processing */}
        <TechStackItem
          icon={<Zap className="w-6 h-6" />}
          title="Analytics Engine"
          color="#0b65b1"
          technologies={[
            { 
              name: 'Python + Pandas', 
              purpose: 'Statistical modeling & anomaly detection algorithms' 
            },
            { 
              name: 'Apache Kafka', 
              purpose: 'Real-time event streaming & signal processing' 
            },
            { 
              name: 'Elasticsearch', 
              purpose: 'Fast search & aggregation of ward-level data' 
            },
            { 
              name: 'ML Models (scikit-learn)', 
              purpose: 'Pattern detection & expenditure estimation' 
            }
          ]}
        />

        {/* Frontend & Visualization */}
        <TechStackItem
          icon={<Code className="w-6 h-6" />}
          title="Frontend Dashboard"
          color="#ff3a21"
          technologies={[
            { 
              name: 'React + TypeScript', 
              purpose: 'Interactive dashboard with real-time updates' 
            },
            { 
              name: 'Mapbox GL JS', 
              purpose: 'Interactive county/ward heat maps & choropleths' 
            },
            { 
              name: 'D3.js + Recharts', 
              purpose: 'Data visualizations, trend lines, & graphs' 
            },
            { 
              name: 'TailwindCSS', 
              purpose: 'Responsive UI design system' 
            }
          ]}
        />

        {/* Security & Privacy */}
        <TechStackItem
          icon={<Lock className="w-6 h-6" />}
          title="Security & Privacy"
          color="#0b65b1"
          technologies={[
            { 
              name: 'Zero-Knowledge Architecture', 
              purpose: 'No personally identifiable information (PII) stored' 
            },
            { 
              name: 'End-to-End Encryption', 
              purpose: 'Signal data encrypted in transit & at rest' 
            },
            { 
              name: 'Rate Limiting & Captcha', 
              purpose: 'Protection against coordinated manipulation attacks' 
            },
            { 
              name: 'Audit Logging', 
              purpose: 'Transparent operation logs for accountability' 
            }
          ]}
        />
      </div>

      {/* Data Sources Section */}
      <div className="mt-12 bg-gradient-to-r from-[#ff3a21] to-[#0b65b1] rounded-xl p-8 text-white">
        <h3 className="text-2xl font-bold mb-6 text-center">Data Sources & Integration</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white/10 backdrop-blur rounded-lg p-4">
            <h4 className="font-bold mb-3 flex items-center gap-2">
              <span className="text-2xl">📊</span> Primary Data Sources
            </h4>
            <ul className="space-y-2 text-sm">
              <li>• <strong>Citizen Signals:</strong> Anonymous ward-level reports via USSD/WhatsApp</li>
              <li>• <strong>IEBC Official Declarations:</strong> Candidate finance disclosures (public record)</li>
              <li>• <strong>County Election Boards:</strong> Registration & constituency data</li>
              <li>• <strong>Media Reports:</strong> Scraped news articles on campaign financing</li>
            </ul>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-lg p-4">
            <h4 className="font-bold mb-3 flex items-center gap-2">
              <span className="text-2xl">🔗</span> External Integrations
            </h4>
            <ul className="space-y-2 text-sm">
              <li>• <strong>IEBC API:</strong> Real-time access to candidate declarations</li>
              <li>• <strong>Kenya Open Data:</strong> Ward boundaries, population statistics</li>
              <li>• <strong>M-Pesa API:</strong> (Future) Transaction pattern analysis</li>
              <li>• <strong>Social Media APIs:</strong> Public sentiment & verification</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
