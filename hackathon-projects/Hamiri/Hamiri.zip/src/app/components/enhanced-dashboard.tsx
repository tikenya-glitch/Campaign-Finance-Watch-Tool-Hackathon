import React, { useState } from 'react';
import { TrendingUp, TrendingDown, AlertTriangle, Activity, Target, Calculator, BarChart3, Clock, Download, Users, MapPin, Filter, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CandidateData {
  id: string;
  name: string;
  party: string;
  position: 'Presidential' | 'Governor' | 'MP' | 'MCA';
  county: string;
  declared: number;
  estimated: number;
  gap: number;
  intensity: 'low' | 'medium' | 'high' | 'critical';
  signals: number;
  anomalyScore: number;
  weeklyTrend: number[];
  benchmarkViolations: string[];
}

interface PartyData {
  name: string;
  color: string;
  totalDeclared: number;
  totalEstimated: number;
  candidates: number;
  avgAnomaly: number;
}

const mockParties: PartyData[] = [
  { name: 'Orange Democratic Movement (ODM)', color: '#FF6B00', totalDeclared: 234000000, totalEstimated: 567000000, candidates: 47, avgAnomaly: 6.8 },
  { name: 'United Democratic Alliance (UDA)', color: '#FFD700', totalDeclared: 289000000, totalEstimated: 712000000, candidates: 52, avgAnomaly: 7.2 },
  { name: 'Azimio la Umoja', color: '#0066CC', totalDeclared: 198000000, totalEstimated: 445000000, candidates: 38, avgAnomaly: 5.9 },
  { name: 'Kenya Kwanza Alliance', color: '#006400', totalDeclared: 267000000, totalEstimated: 623000000, candidates: 45, avgAnomaly: 6.5 }
];

const mockCandidates: CandidateData[] = [
  {
    id: '1',
    name: 'John Kamau',
    party: 'UDA',
    position: 'Governor',
    county: 'Nairobi',
    declared: 50000000,
    estimated: 156000000,
    gap: 212,
    intensity: 'critical',
    signals: 1247,
    anomalyScore: 9.4,
    weeklyTrend: [45, 67, 89, 134, 178, 212],
    benchmarkViolations: ['Mathematical impossibility', 'Velocity spike', 'IEBC cap exceeded']
  },
  {
    id: '2',
    name: 'Mary Njeri',
    party: 'ODM',
    position: 'MP',
    county: 'Kiambu',
    declared: 35000000,
    estimated: 89000000,
    gap: 154,
    intensity: 'high',
    signals: 892,
    anomalyScore: 7.8,
    weeklyTrend: [32, 56, 78, 98, 134, 154],
    benchmarkViolations: ['Velocity spike', 'Ward cluster anomaly']
  },
  {
    id: '3',
    name: 'Peter Omondi',
    party: 'Azimio',
    position: 'Governor',
    county: 'Kisumu',
    declared: 24000000,
    estimated: 45000000,
    gap: 88,
    intensity: 'medium',
    signals: 521,
    anomalyScore: 4.9,
    weeklyTrend: [15, 28, 42, 56, 71, 88],
    benchmarkViolations: ['Pattern inconsistency']
  },
  {
    id: '4',
    name: 'Grace Wanjiku',
    party: 'Kenya Kwanza',
    position: 'MP',
    county: 'Nakuru',
    declared: 32000000,
    estimated: 78000000,
    gap: 144,
    intensity: 'high',
    signals: 734,
    anomalyScore: 7.3,
    weeklyTrend: [28, 45, 67, 89, 112, 144],
    benchmarkViolations: ['Mathematical impossibility', 'Velocity spike']
  },
  {
    id: '5',
    name: 'Hassan Ali',
    party: 'ODM',
    position: 'MCA',
    county: 'Mombasa',
    declared: 8000000,
    estimated: 12000000,
    gap: 50,
    intensity: 'medium',
    signals: 234,
    anomalyScore: 3.2,
    weeklyTrend: [12, 18, 28, 35, 43, 50],
    benchmarkViolations: []
  }
];

const countyData = [
  { name: 'Nairobi', candidates: 12, declared: 125000000, estimated: 342000000, signals: 2456, wards: 17 },
  { name: 'Kiambu', candidates: 8, declared: 89000000, estimated: 198000000, signals: 1678, wards: 12 },
  { name: 'Mombasa', candidates: 6, declared: 67000000, estimated: 134000000, signals: 1234, wards: 6 },
  { name: 'Nakuru', candidates: 9, declared: 95000000, estimated: 223000000, signals: 1567, wards: 11 },
  { name: 'Kisumu', candidates: 7, declared: 78000000, estimated: 156000000, signals: 1123, wards: 7 }
];

export function EnhancedDashboard() {
  const [selectedView, setSelectedView] = useState<'overview' | 'parties' | 'candidates' | 'counties'>('overview');
  const [selectedCandidate, setSelectedCandidate] = useState<CandidateData | null>(null);
  const [selectedParty, setSelectedParty] = useState<string | null>(null);
  const [filterPosition, setFilterPosition] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const getIntensityColor = (intensity: string) => {
    switch (intensity) {
      case 'critical': return '#ff3a21';
      case 'high': return '#ff6b4a';
      case 'medium': return '#ffa500';
      case 'low': return '#0b65b1';
      default: return '#gray';
    }
  };

  const formatCurrency = (amount: number) => {
    return `KSh ${(amount / 1000000).toFixed(1)}M`;
  };

  const filteredCandidates = mockCandidates.filter(c => {
    const matchesPosition = filterPosition === 'all' || c.position === filterPosition;
    const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         c.party.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         c.county.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesParty = !selectedParty || c.party === selectedParty;
    return matchesPosition && matchesSearch && matchesParty;
  });

  const handleDownloadReport = (type: 'pdf' | 'csv' | 'json') => {
    // Simulate download
    alert(`Downloading ${type.toUpperCase()} report...`);
  };

  return (
    <div className="w-full min-h-screen bg-gray-50">
      {/* Dashboard Header */}
      <div className="bg-gradient-to-r from-[#ff3a21] to-[#0b65b1] text-white p-6 shadow-lg">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold mb-2">Hamiri.ke Campaign Finance Dashboard</h1>
          <p className="text-sm opacity-90">Real-time monitoring of Kenya's 2027 election campaign spending</p>
          
          {/* Live Indicator */}
          <div className="mt-4 flex items-center gap-3">
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="w-3 h-3 rounded-full bg-white"
            />
            <span className="text-sm font-semibold">LIVE - Last updated: 2 minutes ago</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* LEFT PANEL - Metrics & Controls */}
          <div className="lg:col-span-1 space-y-4">
            {/* Quick Stats */}
            <div className="bg-white rounded-xl shadow-lg p-5 border-l-4" style={{ borderLeftColor: '#ff3a21' }}>
              <h3 className="font-bold text-sm mb-4 flex items-center gap-2">
                <Activity className="w-4 h-4" />
                Quick Overview
              </h3>
              
              <div className="space-y-3">
                <div>
                  <div className="text-xs text-gray-600 mb-1">Total Declared</div>
                  <div className="text-xl font-bold" style={{ color: '#0b65b1' }}>
                    {formatCurrency(mockCandidates.reduce((sum, c) => sum + c.declared, 0))}
                  </div>
                </div>
                
                <div className="border-t pt-3">
                  <div className="text-xs text-gray-600 mb-1">Estimated Actual</div>
                  <div className="text-xl font-bold" style={{ color: '#ff3a21' }}>
                    {formatCurrency(mockCandidates.reduce((sum, c) => sum + c.estimated, 0))}
                  </div>
                </div>
                
                <div className="border-t pt-3">
                  <div className="text-xs text-gray-600 mb-1">Total Gap</div>
                  <div className="text-xl font-bold text-gray-900">
                    {formatCurrency(
                      mockCandidates.reduce((sum, c) => sum + c.estimated, 0) - 
                      mockCandidates.reduce((sum, c) => sum + c.declared, 0)
                    )}
                  </div>
                </div>
                
                <div className="border-t pt-3">
                  <div className="text-xs text-gray-600 mb-1">Citizen Signals</div>
                  <div className="text-xl font-bold text-gray-900">
                    {mockCandidates.reduce((sum, c) => sum + c.signals, 0).toLocaleString()}
                  </div>
                </div>

                <div className="border-t pt-3">
                  <div className="text-xs text-gray-600 mb-1">Active Wards</div>
                  <div className="text-xl font-bold text-gray-900">
                    {countyData.reduce((sum, c) => sum + c.wards, 0)}
                  </div>
                </div>
              </div>
            </div>

            {/* Intensity Scale */}
            <div className="bg-white rounded-xl shadow-lg p-5 border-l-4" style={{ borderLeftColor: '#0b65b1' }}>
              <h3 className="font-bold text-sm mb-4 flex items-center gap-2">
                <Target className="w-4 h-4" />
                Intensity Scale
              </h3>
              
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#ff3a21' }}>
                    <span className="text-white text-xs font-bold">🚨</span>
                  </div>
                  <div className="flex-1">
                    <div className="text-xs font-semibold">Critical</div>
                    <div className="text-[10px] text-gray-600">&gt;150% gap</div>
                  </div>
                  <div className="text-sm font-bold" style={{ color: '#ff3a21' }}>
                    {mockCandidates.filter(c => c.intensity === 'critical').length}
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg" style={{ backgroundColor: '#ff6b4a' }}></div>
                  <div className="flex-1">
                    <div className="text-xs font-semibold">High Risk</div>
                    <div className="text-[10px] text-gray-600">100-150%</div>
                  </div>
                  <div className="text-sm font-bold" style={{ color: '#ff6b4a' }}>
                    {mockCandidates.filter(c => c.intensity === 'high').length}
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg" style={{ backgroundColor: '#ffa500' }}></div>
                  <div className="flex-1">
                    <div className="text-xs font-semibold">Medium</div>
                    <div className="text-[10px] text-gray-600">50-100%</div>
                  </div>
                  <div className="text-sm font-bold" style={{ color: '#ffa500' }}>
                    {mockCandidates.filter(c => c.intensity === 'medium').length}
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg" style={{ backgroundColor: '#0b65b1' }}></div>
                  <div className="flex-1">
                    <div className="text-xs font-semibold">Low</div>
                    <div className="text-[10px] text-gray-600">&lt;50%</div>
                  </div>
                  <div className="text-sm font-bold" style={{ color: '#0b65b1' }}>
                    {mockCandidates.filter(c => c.intensity === 'low').length}
                  </div>
                </div>
              </div>
            </div>

            {/* Download Reports */}
            <div className="bg-white rounded-xl shadow-lg p-5 border-l-4" style={{ borderLeftColor: '#ff3a21' }}>
              <h3 className="font-bold text-sm mb-4 flex items-center gap-2">
                <Download className="w-4 h-4" />
                Download Reports
              </h3>
              
              <div className="space-y-2">
                <button 
                  onClick={() => handleDownloadReport('pdf')}
                  className="w-full px-4 py-3 rounded-lg font-semibold text-sm text-white shadow-md hover:shadow-lg transition-all flex items-center justify-between"
                  style={{ backgroundColor: '#ff3a21' }}
                >
                  <span>📄 PDF Report</span>
                  <Download className="w-4 h-4" />
                </button>
                
                <button 
                  onClick={() => handleDownloadReport('csv')}
                  className="w-full px-4 py-3 rounded-lg font-semibold text-sm text-white shadow-md hover:shadow-lg transition-all flex items-center justify-between"
                  style={{ backgroundColor: '#0b65b1' }}
                >
                  <span>📊 CSV Data</span>
                  <Download className="w-4 h-4" />
                </button>
                
                <button 
                  onClick={() => handleDownloadReport('json')}
                  className="w-full px-4 py-3 rounded-lg font-semibold text-sm text-white shadow-md hover:shadow-lg transition-all flex items-center justify-between"
                  style={{ backgroundColor: '#ff3a21' }}
                >
                  <span>💾 JSON Export</span>
                  <Download className="w-4 h-4" />
                </button>
              </div>
              
              <div className="mt-3 text-[10px] text-gray-600 bg-gray-50 rounded p-2">
                <strong>Note:</strong> All downloads are anonymized and aggregated data only.
              </div>
            </div>

            {/* Anomaly Score Legend */}
            <div className="bg-gradient-to-br from-[#0b65b1]/10 to-[#0b65b1]/5 rounded-xl p-5 border-2" style={{ borderColor: '#0b65b1' }}>
              <h3 className="font-bold text-sm mb-3">Anomaly Score</h3>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span>0-2.5</span>
                  <span className="font-semibold text-green-600">Normal</span>
                </div>
                <div className="flex justify-between">
                  <span>2.5-5.0</span>
                  <span className="font-semibold" style={{ color: '#ffa500' }}>Monitor</span>
                </div>
                <div className="flex justify-between">
                  <span>5.0-7.5</span>
                  <span className="font-semibold" style={{ color: '#ff6b4a' }}>Investigate</span>
                </div>
                <div className="flex justify-between">
                  <span>7.5-10</span>
                  <span className="font-semibold" style={{ color: '#ff3a21' }}>Critical</span>
                </div>
              </div>
            </div>
          </div>

          {/* MAIN CONTENT AREA */}
          <div className="lg:col-span-3 space-y-6">
            {/* View Selector */}
            <div className="bg-white rounded-xl shadow-lg p-4">
              <div className="flex gap-2 flex-wrap">
                <button
                  onClick={() => setSelectedView('overview')}
                  className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                    selectedView === 'overview'
                      ? 'text-white shadow-lg'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                  style={selectedView === 'overview' ? { backgroundColor: '#ff3a21' } : {}}
                >
                  📊 Overview
                </button>
                <button
                  onClick={() => setSelectedView('parties')}
                  className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                    selectedView === 'parties'
                      ? 'text-white shadow-lg'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                  style={selectedView === 'parties' ? { backgroundColor: '#0b65b1' } : {}}
                >
                  🎯 Political Parties
                </button>
                <button
                  onClick={() => setSelectedView('candidates')}
                  className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                    selectedView === 'candidates'
                      ? 'text-white shadow-lg'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                  style={selectedView === 'candidates' ? { backgroundColor: '#ff3a21' } : {}}
                >
                  👤 Candidates
                </button>
                <button
                  onClick={() => setSelectedView('counties')}
                  className={`px-6 py-3 rounded-lg font-semibold transition-all ${
                    selectedView === 'counties'
                      ? 'text-white shadow-lg'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                  style={selectedView === 'counties' ? { backgroundColor: '#0b65b1' } : {}}
                >
                  🗺️ County Heat Map
                </button>
              </div>
            </div>

            {/* Content Area */}
            <AnimatePresence mode="wait">
              {selectedView === 'overview' && (
                <motion.div
                  key="overview"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-6"
                >
                  {/* Overview Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-white rounded-xl shadow-lg p-6 border-t-4" style={{ borderTopColor: '#ff3a21' }}>
                      <div className="text-sm text-gray-600 mb-2">Total Candidates Tracked</div>
                      <div className="text-4xl font-bold text-gray-900">{mockCandidates.length}</div>
                      <div className="text-xs text-gray-500 mt-2">Across 5 counties</div>
                    </div>
                    
                    <div className="bg-white rounded-xl shadow-lg p-6 border-t-4" style={{ borderTopColor: '#0b65b1' }}>
                      <div className="text-sm text-gray-600 mb-2">Political Parties</div>
                      <div className="text-4xl font-bold text-gray-900">{mockParties.length}</div>
                      <div className="text-xs text-gray-500 mt-2">Major coalitions</div>
                    </div>
                    
                    <div className="bg-white rounded-xl shadow-lg p-6 border-t-4" style={{ borderTopColor: '#ff3a21' }}>
                      <div className="text-sm text-gray-600 mb-2">Avg Anomaly Score</div>
                      <div className="text-4xl font-bold" style={{ color: '#ff3a21' }}>
                        {(mockCandidates.reduce((sum, c) => sum + c.anomalyScore, 0) / mockCandidates.length).toFixed(1)}
                      </div>
                      <div className="text-xs text-gray-500 mt-2">Out of 10</div>
                    </div>
                  </div>

                  {/* Top Violators */}
                  <div className="bg-white rounded-xl shadow-lg p-6">
                    <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5" style={{ color: '#ff3a21' }} />
                      Top 5 High-Risk Candidates
                    </h3>
                    <div className="space-y-3">
                      {mockCandidates
                        .sort((a, b) => b.anomalyScore - a.anomalyScore)
                        .slice(0, 5)
                        .map((candidate, idx) => (
                          <div key={candidate.id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg border-l-4"
                            style={{ borderLeftColor: getIntensityColor(candidate.intensity) }}>
                            <div className="text-2xl font-bold text-gray-400">#{idx + 1}</div>
                            <div className="flex-1">
                              <div className="font-bold text-gray-900">{candidate.name}</div>
                              <div className="text-sm text-gray-600">{candidate.party} • {candidate.position} • {candidate.county}</div>
                            </div>
                            <div className="text-right">
                              <div className="text-sm text-gray-600">Anomaly Score</div>
                              <div className="text-2xl font-bold" style={{ color: getIntensityColor(candidate.intensity) }}>
                                {candidate.anomalyScore}
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-sm text-gray-600">Gap</div>
                              <div className="text-xl font-bold" style={{ color: '#ff3a21' }}>
                                +{candidate.gap}%
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                </motion.div>
              )}

              {selectedView === 'parties' && (
                <motion.div
                  key="parties"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-4"
                >
                  {mockParties.map((party) => (
                    <div key={party.name} className="bg-white rounded-xl shadow-lg overflow-hidden border-l-4"
                      style={{ borderLeftColor: party.color }}>
                      <div className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h3 className="font-bold text-xl text-gray-900">{party.name}</h3>
                            <div className="text-sm text-gray-600 mt-1">{party.candidates} candidates tracked</div>
                          </div>
                          <div className="px-4 py-2 rounded-lg text-white font-bold text-sm"
                            style={{ backgroundColor: party.color }}>
                            Party Score: {party.avgAnomaly.toFixed(1)}
                          </div>
                        </div>

                        <div className="grid grid-cols-3 gap-4">
                          <div className="bg-gray-50 rounded-lg p-4">
                            <div className="text-xs text-gray-600 mb-1">Total Declared</div>
                            <div className="text-xl font-bold" style={{ color: '#0b65b1' }}>
                              {formatCurrency(party.totalDeclared)}
                            </div>
                          </div>
                          
                          <div className="bg-gray-50 rounded-lg p-4">
                            <div className="text-xs text-gray-600 mb-1">Estimated Actual</div>
                            <div className="text-xl font-bold" style={{ color: '#ff3a21' }}>
                              {formatCurrency(party.totalEstimated)}
                            </div>
                          </div>
                          
                          <div className="bg-gray-50 rounded-lg p-4">
                            <div className="text-xs text-gray-600 mb-1">Gap</div>
                            <div className="text-xl font-bold" style={{ color: '#ff3a21' }}>
                              +{Math.round((party.totalEstimated - party.totalDeclared) / party.totalDeclared * 100)}%
                            </div>
                          </div>
                        </div>

                        <button
                          onClick={() => setSelectedParty(party.name === selectedParty ? null : party.name)}
                          className="mt-4 w-full px-4 py-2 rounded-lg font-semibold text-sm transition-all"
                          style={{ 
                            backgroundColor: selectedParty === party.name ? party.color : `${party.color}20`,
                            color: selectedParty === party.name ? 'white' : party.color
                          }}
                        >
                          {selectedParty === party.name ? 'Hide' : 'View'} Party Candidates
                        </button>
                      </div>
                    </div>
                  ))}
                </motion.div>
              )}

              {selectedView === 'candidates' && (
                <motion.div
                  key="candidates"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-4"
                >
                  {/* Search and Filters */}
                  <div className="bg-white rounded-xl shadow-lg p-4">
                    <div className="flex gap-4 flex-wrap">
                      <div className="flex-1 min-w-[200px]">
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                          <input
                            type="text"
                            placeholder="Search candidates, parties, counties..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="w-full pl-10 pr-4 py-3 rounded-lg border-2 border-gray-200 focus:border-[#0b65b1] outline-none"
                          />
                        </div>
                      </div>
                      
                      <select
                        value={filterPosition}
                        onChange={(e) => setFilterPosition(e.target.value)}
                        className="px-4 py-3 rounded-lg border-2 border-gray-200 font-semibold"
                      >
                        <option value="all">All Positions</option>
                        <option value="Governor">Governor</option>
                        <option value="MP">Member of Parliament</option>
                        <option value="MCA">Member of County Assembly</option>
                        <option value="Presidential">Presidential</option>
                      </select>
                    </div>
                  </div>

                  {/* Candidates List */}
                  <div className="space-y-3">
                    {filteredCandidates.map((candidate) => (
                      <div key={candidate.id} 
                        className="bg-white rounded-xl shadow-lg overflow-hidden border-l-4 cursor-pointer hover:shadow-xl transition-all"
                        style={{ borderLeftColor: getIntensityColor(candidate.intensity) }}
                        onClick={() => setSelectedCandidate(selectedCandidate?.id === candidate.id ? null : candidate)}
                      >
                        <div className="p-6">
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex-1">
                              <h3 className="font-bold text-xl text-gray-900">{candidate.name}</h3>
                              <div className="flex items-center gap-3 mt-2 text-sm text-gray-600">
                                <span className="font-semibold" style={{ 
                                  color: mockParties.find(p => candidate.party.includes(p.name.split(' ')[0]))?.color || '#gray'
                                }}>
                                  {candidate.party}
                                </span>
                                <span>•</span>
                                <span>{candidate.position}</span>
                                <span>•</span>
                                <span>{candidate.county} County</span>
                              </div>
                            </div>
                            <div className="flex items-center gap-3">
                              <div className="text-right">
                                <div className="text-xs text-gray-600">Anomaly Score</div>
                                <div className="text-3xl font-bold" style={{ color: getIntensityColor(candidate.intensity) }}>
                                  {candidate.anomalyScore}
                                </div>
                              </div>
                              <div className="px-3 py-1 rounded-full text-white text-xs font-bold"
                                style={{ backgroundColor: getIntensityColor(candidate.intensity) }}>
                                {candidate.intensity.toUpperCase()}
                              </div>
                            </div>
                          </div>

                          <div className="grid grid-cols-4 gap-4">
                            <div className="bg-gray-50 rounded-lg p-3">
                              <div className="text-xs text-gray-600 mb-1">Declared</div>
                              <div className="text-base font-bold" style={{ color: '#0b65b1' }}>
                                {formatCurrency(candidate.declared)}
                              </div>
                            </div>
                            
                            <div className="bg-gray-50 rounded-lg p-3">
                              <div className="text-xs text-gray-600 mb-1">Estimated</div>
                              <div className="text-base font-bold" style={{ color: '#ff3a21' }}>
                                {formatCurrency(candidate.estimated)}
                              </div>
                            </div>
                            
                            <div className="bg-gray-50 rounded-lg p-3">
                              <div className="text-xs text-gray-600 mb-1">Gap</div>
                              <div className="text-base font-bold" style={{ color: '#ff3a21' }}>
                                +{candidate.gap}%
                              </div>
                            </div>
                            
                            <div className="bg-gray-50 rounded-lg p-3">
                              <div className="text-xs text-gray-600 mb-1">Signals</div>
                              <div className="text-base font-bold text-gray-900">
                                {candidate.signals}
                              </div>
                            </div>
                          </div>

                          {selectedCandidate?.id === candidate.id && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              className="mt-4 pt-4 border-t"
                            >
                              <div className="grid grid-cols-2 gap-4">
                                {/* Weekly Trend */}
                                <div className="bg-gray-50 rounded-lg p-4">
                                  <h4 className="font-bold text-sm mb-3">6-Week Trend</h4>
                                  <div className="space-y-2">
                                    {candidate.weeklyTrend.map((value, idx) => (
                                      <div key={idx} className="flex items-center gap-2">
                                        <span className="text-xs text-gray-600 w-12">W{idx + 1}</span>
                                        <div className="flex-1 bg-white rounded-full h-5 overflow-hidden">
                                          <div
                                            className="h-5 flex items-center justify-end pr-2"
                                            style={{ 
                                              width: `${(value / Math.max(...candidate.weeklyTrend)) * 100}%`,
                                              backgroundColor: getIntensityColor(candidate.intensity)
                                            }}
                                          >
                                            <span className="text-[10px] font-bold text-white">{value}%</span>
                                          </div>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                </div>

                                {/* Benchmark Violations */}
                                <div className="bg-gray-50 rounded-lg p-4">
                                  <h4 className="font-bold text-sm mb-3">Benchmark Violations</h4>
                                  {candidate.benchmarkViolations.length > 0 ? (
                                    <div className="space-y-2">
                                      {candidate.benchmarkViolations.map((violation, idx) => (
                                        <div key={idx} className="flex items-start gap-2 text-xs">
                                          <AlertTriangle className="w-3 h-3 mt-0.5" style={{ color: '#ff3a21' }} />
                                          <span>{violation}</span>
                                        </div>
                                      ))}
                                    </div>
                                  ) : (
                                    <div className="text-xs text-green-600">✓ No violations detected</div>
                                  )}
                                </div>
                              </div>
                            </motion.div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}

              {selectedView === 'counties' && (
                <motion.div
                  key="counties"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="bg-white rounded-xl shadow-lg p-6"
                >
                  <h3 className="font-bold text-xl mb-6 flex items-center gap-2">
                    <MapPin className="w-6 h-6" style={{ color: '#ff3a21' }} />
                    County Heat Map
                  </h3>
                  
                  <div className="grid grid-cols-1 gap-4">
                    {countyData.map((county, idx) => {
                      const gap = Math.round((county.estimated - county.declared) / county.declared * 100);
                      const intensity = gap > 150 ? 'critical' : gap > 100 ? 'high' : gap > 50 ? 'medium' : 'low';
                      
                      return (
                        <div key={county.name} 
                          className="p-6 rounded-xl border-l-4 bg-gradient-to-r from-white to-gray-50"
                          style={{ borderLeftColor: getIntensityColor(intensity) }}
                        >
                          <div className="flex items-start justify-between mb-4">
                            <div>
                              <h4 className="font-bold text-lg">{county.name} County</h4>
                              <div className="text-sm text-gray-600 mt-1">
                                {county.candidates} candidates • {county.wards} wards • {county.signals.toLocaleString()} signals
                              </div>
                            </div>
                            <div className="px-4 py-2 rounded-lg text-white font-bold"
                              style={{ backgroundColor: getIntensityColor(intensity) }}>
                              +{gap}%
                            </div>
                          </div>

                          <div className="grid grid-cols-3 gap-4">
                            <div>
                              <div className="text-xs text-gray-600 mb-1">Declared Budget</div>
                              <div className="text-xl font-bold" style={{ color: '#0b65b1' }}>
                                {formatCurrency(county.declared)}
                              </div>
                            </div>
                            <div>
                              <div className="text-xs text-gray-600 mb-1">Estimated Actual</div>
                              <div className="text-xl font-bold" style={{ color: '#ff3a21' }}>
                                {formatCurrency(county.estimated)}
                              </div>
                            </div>
                            <div>
                              <div className="text-xs text-gray-600 mb-1">Ward Breakdown</div>
                              <button className="text-sm font-semibold underline" style={{ color: '#0b65b1' }}>
                                View {county.wards} wards →
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}
