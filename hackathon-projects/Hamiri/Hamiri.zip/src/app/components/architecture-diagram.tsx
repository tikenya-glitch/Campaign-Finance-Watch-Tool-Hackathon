import React from 'react';
import { ArrowDown, Database, MapPin, TrendingUp, Users, Shield, Globe, AlertCircle } from 'lucide-react';

interface ArchitectureLayerProps {
  title: string;
  color: string;
  items: string[];
  icon?: React.ReactNode;
}

function ArchitectureLayer({ title, color, items, icon }: ArchitectureLayerProps) {
  return (
    <div className="w-full">
      <div
        className="rounded-lg p-6 shadow-lg border-2"
        style={{ 
          backgroundColor: `${color}15`,
          borderColor: color 
        }}
      >
        <div className="flex items-center gap-3 mb-4">
          {icon && <div style={{ color }}>{icon}</div>}
          <h3 className="font-bold text-lg" style={{ color }}>{title}</h3>
        </div>
        <ul className="space-y-2">
          {items.map((item, idx) => (
            <li key={idx} className="text-sm text-gray-700 flex items-start gap-2">
              <span className="text-lg leading-none" style={{ color }}>•</span>
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export function ArchitectureDiagram() {
  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 py-8">
      {/* Ground Layer */}
      <ArchitectureLayer
        title="GROUND LAYER (Data Collection)"
        color="#ff3a21"
        icon={<Users className="w-6 h-6" />}
        items={[
          'WhatsApp Bot Agent - Conversational interface in Kiswahili, Sheng, and local languages',
          'USSD Short Code (*384*96#) - Works on all phones, no internet required',
          'Anonymous ward-level signals from citizens nationwide',
          'Vote buying reports, amounts offered, frequency patterns',
          'Zero-knowledge collection - individual identity never stored'
        ]}
      />

      <div className="flex justify-center">
        <ArrowDown className="w-8 h-8 text-gray-400" />
      </div>

      {/* Intelligence Layer */}
      <ArchitectureLayer
        title="INTELLIGENCE LAYER (Data Processing)"
        color="#0b65b1"
        icon={<Database className="w-6 h-6" />}
        items={[
          'Hamiri Ke Platform Engine - Real-time signal aggregation',
          'Cross-references citizen signals with official IEBC declarations',
          'Detects velocity spikes and manipulation patterns',
          'Generates ward-level expenditure estimates using statistical modeling',
          'Flags mathematical impossibilities in candidate disclosures',
          'Anomaly detection algorithms identify outliers'
        ]}
      />

      <div className="flex justify-center">
        <ArrowDown className="w-8 h-8 text-gray-400" />
      </div>

      {/* Visualization Layer */}
      <ArchitectureLayer
        title="VISUALIZATION LAYER (Public Platform)"
        color="#ff3a21"
        icon={<TrendingUp className="w-6 h-6" />}
        items={[
          'Interactive Dashboard - Built like Ushahidi for finance tracking',
          'County-level heat maps showing vote buying intensity',
          'Candidate finance profiles vs. ground signals comparison',
          'Ward expenditure estimates vs. declared spend analysis',
          'Week-on-week trend lines per constituency',
          'Traffic light compliance indicators (Green/Yellow/Red) per candidate'
        ]}
      />

      <div className="flex justify-center">
        <ArrowDown className="w-8 h-8 text-gray-400" />
      </div>

      {/* Dissemination Layer */}
      <ArchitectureLayer
        title="DISSEMINATION LAYER (Action & Accountability)"
        color="#0b65b1"
        icon={<Globe className="w-6 h-6" />}
        items={[
          'Journalists - Downloadable anomaly reports and story leads',
          'Researchers - Anonymized county-level datasets for analysis',
          'IEBC - Mathematical contradiction flags for investigation',
          'Civil Society - Real-time monitoring dashboards',
          'Public - Simple, shareable ward summaries in plain language',
          'Media - Weekly data briefings and embargo-ready visualizations'
        ]}
      />
    </div>
  );
}
