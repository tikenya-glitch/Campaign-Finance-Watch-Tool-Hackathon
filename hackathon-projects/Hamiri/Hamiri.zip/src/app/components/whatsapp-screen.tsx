import React from 'react';

interface Message {
  type: 'bot' | 'user';
  text: string;
  time: string;
}

interface WhatsAppScreenProps {
  messages: Message[];
}

export function WhatsAppScreen({ messages }: WhatsAppScreenProps) {
  return (
    <div className="h-full flex flex-col bg-[#e5ddd5]">
      {/* WhatsApp Header */}
      <div className="bg-[#075e54] text-white px-4 py-3 flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center text-gray-700 font-semibold text-sm">
          HK
        </div>
        <div className="flex-1">
          <h3 className="text-sm font-semibold">Hamiri Ke Bot</h3>
          <p className="text-xs opacity-80">online</p>
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 overflow-auto p-3 space-y-2">
        {messages.map((message, idx) => (
          <div
            key={idx}
            className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`
                max-w-[80%] rounded-lg px-3 py-2 shadow-sm
                ${message.type === 'user' 
                  ? 'bg-[#dcf8c6]' 
                  : 'bg-white'
                }
              `}
            >
              <p className="text-sm text-gray-900 whitespace-pre-wrap">{message.text}</p>
              <p className="text-[10px] text-gray-600 text-right mt-1">{message.time}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Input Area */}
      <div className="bg-[#f0f0f0] px-2 py-2 flex items-center gap-2">
        <div className="flex-1 bg-white rounded-full px-4 py-2 text-sm text-gray-500">
          Type a message...
        </div>
        <div className="w-8 h-8 bg-[#075e54] rounded-full flex items-center justify-center text-white">
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
            <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
          </svg>
        </div>
      </div>
    </div>
  );
}
