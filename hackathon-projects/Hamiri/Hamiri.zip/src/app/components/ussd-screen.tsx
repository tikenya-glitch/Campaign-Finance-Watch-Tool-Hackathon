import React from 'react';

interface USSDScreenProps {
  step: 'initial' | 'language' | 'main-menu' | 'report-type' | 'location' | 'candidate' | 'amount' | 'evidence' | 'crowd' | 'confirmation';
  language?: 'english' | 'kiswahili' | 'sheng';
}

export function USSDScreen({ step, language = 'english' }: USSDScreenProps) {
  const getContent = () => {
    switch (step) {
      case 'initial':
        return {
          title: 'HAMIRI KE',
          content: (
            <div className="space-y-2">
              <p className="text-sm font-semibold">Welcome to Hamiri Ke</p>
              <p className="text-sm">Campaign Finance Watch</p>
              <div className="border-t border-gray-300 my-2"></div>
              <p className="text-sm">Choose Language:</p>
              <p className="text-sm">1. Kiswahili</p>
              <p className="text-sm">2. English</p>
              <p className="text-sm">3. Sheng</p>
              <p className="text-sm">4. Local Language</p>
              <div className="border-t border-gray-300 my-2"></div>
              <p className="text-xs text-gray-600">Reply with number</p>
            </div>
          )
        };
      
      case 'language':
        return {
          title: 'HAMIRI KE',
          content: (
            <div className="space-y-2">
              <p className="text-sm font-semibold">Select Local Language:</p>
              <div className="border-t border-gray-300 my-2"></div>
              <p className="text-sm">1. Kikuyu</p>
              <p className="text-sm">2. Luo</p>
              <p className="text-sm">3. Kalenjin</p>
              <p className="text-sm">4. Luhya</p>
              <p className="text-sm">5. Kamba</p>
              <div className="border-t border-gray-300 my-2"></div>
              <p className="text-xs text-gray-600">Reply with number</p>
            </div>
          )
        };

      case 'main-menu':
        const menuText = {
          english: {
            items: [
              '1. Report Campaign Spending',
              '2. See Spending Trends',
              '3. Learn Your Rights',
              '4. About Hamiri Ke',
              '0. Exit'
            ]
          },
          kiswahili: {
            items: [
              '1. Ripoti Matumizi ya Kampeni',
              '2. Angalia Mwenendo',
              '3. Jifunze Haki Zako',
              '4. Kuhusu Hamiri Ke',
              '0. Toka'
            ]
          },
          sheng: {
            items: [
              '1. Report Doh ya Kampeni',
              '2. Check Trends',
              '3. Jua Rights Zako',
              '4. Kuhusu Hamiri Ke',
              '0. Ishia'
            ]
          }
        };
        
        return {
          title: 'HAMIRI KE',
          content: (
            <div className="space-y-2">
              <p className="text-sm font-semibold">Main Menu</p>
              <div className="border-t border-gray-300 my-2"></div>
              {menuText[language].items.map((item, idx) => (
                <p key={idx} className="text-sm">{item}</p>
              ))}
              <div className="border-t border-gray-300 my-2"></div>
              <p className="text-xs text-gray-600">Reply with number</p>
            </div>
          )
        };

      case 'report-type':
        const reportTypes = {
          english: {
            title: 'Where did you see campaign spending?',
            options: [
              '1. Rally/Event',
              '2. Handouts / Cash',
              '3. Transport (Bus, Boda)',
              '4. Posters/Billboards',
              '5. Food / Gifts',
              '6. Other'
            ]
          },
          kiswahili: {
            title: 'Wapi uliona matumizi ya kampeni?',
            options: [
              '1. Mkutano/Hafla',
              '2. Pesa / Zawadi',
              '3. Usafiri (Bus, Boda)',
              '4. Mabango/Bango',
              '5. Chakula / Vitu',
              '6. Nyingine'
            ]
          },
          sheng: {
            title: 'Wapi ulicheki spending ya kampeni?',
            options: [
              '1. Rally/Event',
              '2. Doh / Handouts',
              '3. Transport (Gari, Boda)',
              '4. Posters/Mabango',
              '5. Dishi / Gifts',
              '6. Zingine'
            ]
          }
        };
        
        const report = reportTypes[language];
        return {
          title: 'HAMIRI KE',
          content: (
            <div className="space-y-2">
              <p className="text-sm font-semibold">{report.title}</p>
              <div className="border-t border-gray-300 my-2"></div>
              {report.options.map((option, idx) => (
                <p key={idx} className="text-sm">{option}</p>
              ))}
              <div className="border-t border-gray-300 my-2"></div>
              <p className="text-xs text-gray-600">Reply with number</p>
            </div>
          )
        };

      case 'location':
        return {
          title: 'HAMIRI KE',
          content: (
            <div className="space-y-2">
              <p className="text-sm font-semibold">Select your County:</p>
              <div className="border-t border-gray-300 my-2"></div>
              <p className="text-sm">1. Nairobi</p>
              <p className="text-sm">2. Kiambu</p>
              <p className="text-sm">3. Nakuru</p>
              <p className="text-sm">4. Kisumu</p>
              <p className="text-sm">5. Mombasa</p>
              <p className="text-sm">6. Other</p>
              <div className="border-t border-gray-300 my-2"></div>
              <p className="text-xs text-gray-600">Next: Enter Ward Code</p>
            </div>
          )
        };

      case 'candidate':
        const candidateText = {
          english: {
            title: 'Who organized the spending?',
            options: [
              '1. Presidential Candidate',
              '2. Governor Candidate',
              '3. MP Candidate',
              '4. MCA Candidate',
              '5. Party Event',
              '6. Not Sure'
            ],
            next: 'Next: Enter candidate/party name'
          },
          kiswahili: {
            title: 'Nani aliandaa matumizi?',
            options: [
              '1. Mgombea Urais',
              '2. Mgombea Gavana',
              '3. Mgombea Ubunge',
              '4. Mgombea MCA',
              '5. Hafla ya Chama',
              '6. Sijui'
            ],
            next: 'Baadaye: Weka jina la mgombea'
          },
          sheng: {
            title: 'Nani aliorganize spending?',
            options: [
              '1. Mgombea Prezzo',
              '2. Mgombea Gova',
              '3. Mgombea MP',
              '4. Mgombea MCA',
              '5. Event ya Party',
              '6. Sijui'
            ],
            next: 'Next: Weka jina ya mgombea'
          }
        };
        
        const cand = candidateText[language];
        return {
          title: 'HAMIRI KE',
          content: (
            <div className="space-y-2">
              <p className="text-sm font-semibold">{cand.title}</p>
              <div className="border-t border-gray-300 my-2"></div>
              {cand.options.map((option, idx) => (
                <p key={idx} className="text-sm">{option}</p>
              ))}
              <div className="border-t border-gray-300 my-2"></div>
              <p className="text-xs text-gray-600">{cand.next}</p>
            </div>
          )
        };

      case 'amount':
        const amountText = {
          english: 'Estimated spending?',
          kiswahili: 'Kiasi cha matumizi?',
          sheng: 'Bei gani uliona?'
        };
        
        return {
          title: 'HAMIRI KE',
          content: (
            <div className="space-y-2">
              <p className="text-sm font-semibold">{amountText[language]}</p>
              <div className="border-t border-gray-300 my-2"></div>
              <p className="text-sm">1. Below 10,000 KES</p>
              <p className="text-sm">2. 10K - 50K</p>
              <p className="text-sm">3. 50K - 200K</p>
              <p className="text-sm">4. 200K - 1M</p>
              <p className="text-sm">5. Above 1M</p>
              <div className="border-t border-gray-300 my-2"></div>
              <p className="text-xs text-gray-600">Reply with number</p>
            </div>
          )
        };

      case 'evidence':
        const evidenceText = {
          english: 'Did you see any of these?',
          kiswahili: 'Je, uliona mojawapo ya hizi?',
          sheng: 'Ulicheki any ya hizi?'
        };
        
        return {
          title: 'HAMIRI KE',
          content: (
            <div className="space-y-2">
              <p className="text-sm font-semibold">{evidenceText[language]}</p>
              <div className="border-t border-gray-300 my-2"></div>
              <p className="text-sm">1. Cash distribution</p>
              <p className="text-sm">2. Food or goods</p>
              <p className="text-sm">3. Paid transport</p>
              <p className="text-sm">4. Stage/sound setup</p>
              <p className="text-sm">5. Posters / banners</p>
              <p className="text-sm">6. Other</p>
              <div className="border-t border-gray-300 my-2"></div>
              <p className="text-xs text-gray-600">Reply with number</p>
            </div>
          )
        };

      case 'crowd':
        const crowdText = {
          english: 'How many people attended?',
          kiswahili: 'Watu wangapi walikuwepo?',
          sheng: 'Watu wangapi walikuwa?'
        };
        
        return {
          title: 'HAMIRI KE',
          content: (
            <div className="space-y-2">
              <p className="text-sm font-semibold">{crowdText[language]}</p>
              <div className="border-t border-gray-300 my-2"></div>
              <p className="text-sm">1. Below 50</p>
              <p className="text-sm">2. 50 - 200</p>
              <p className="text-sm">3. 200 - 1000</p>
              <p className="text-sm">4. 1000+</p>
              <div className="border-t border-gray-300 my-2"></div>
              <p className="text-xs text-gray-600">Reply with number</p>
            </div>
          )
        };
      
      case 'confirmation':
        const thanks = {
          english: {
            title: 'Thank you!',
            message: 'Your anonymous report helps track campaign spending.',
            reportId: 'Report ID: 84721',
            options: [
              '1. Submit another report',
              '2. Main menu',
              '0. Exit'
            ]
          },
          kiswahili: {
            title: 'Asante!',
            message: 'Ripoti yako ya siri inasaidia kufuatilia matumizi ya kampeni.',
            reportId: 'Nambari ya Ripoti: 84721',
            options: [
              '1. Tuma ripoti nyingine',
              '2. Menu kuu',
              '0. Toka'
            ]
          },
          sheng: {
            title: 'Asante!',
            message: 'Report yako ya siri inasaidia kutrack spending ya kampeni.',
            reportId: 'Report ID: 84721',
            options: [
              '1. Tuma report ingine',
              '2. Main menu',
              '0. Ishia'
            ]
          }
        };
        
        const confirm = thanks[language];
        return {
          title: 'HAMIRI KE',
          content: (
            <div className="space-y-2">
              <p className="text-sm font-semibold">✓ {confirm.title}</p>
              <div className="border-t border-gray-300 my-2"></div>
              <p className="text-xs text-gray-700">{confirm.message}</p>
              <p className="text-xs font-semibold text-gray-900 mt-2">{confirm.reportId}</p>
              <div className="border-t border-gray-300 my-2"></div>
              {confirm.options.map((option, idx) => (
                <p key={idx} className="text-sm">{option}</p>
              ))}
            </div>
          )
        };
    }
  };

  const { title, content } = getContent();

  return (
    <div className="bg-gray-100 h-full p-4">
      <div className="bg-white border-2 border-gray-800 rounded-lg p-3 shadow-sm font-mono text-gray-900">
        <div className="text-center border-b-2 border-gray-800 pb-2 mb-3">
          <h3 className="font-bold">{title}</h3>
        </div>
        {content}
      </div>
    </div>
  );
}
