import React, { useState } from 'react';
import { MobileDevice } from './mobile-device';
import { WhatsAppScreen } from './whatsapp-screen';
import { motion } from 'motion/react';

const conversationFlows = {
  english: [
    { type: 'bot' as const, text: 'Hi! I\'m Hamiri Ke Bot 🇰🇪\n\nI help track campaign financing by collecting anonymous signals from citizens like you.\n\nYour identity is NEVER stored. Would you like to continue?', time: '3:45 PM' },
    { type: 'user' as const, text: 'Yes', time: '3:45 PM' },
    { type: 'bot' as const, text: 'Great! Quick question:\n\nHas vote-buying money reached your area this week?\n\n1️⃣ YES\n2️⃣ NO\n3️⃣ NOT SURE\n\nReply with 1, 2, or 3', time: '3:45 PM' },
    { type: 'user' as const, text: '1', time: '3:46 PM' },
    { type: 'bot' as const, text: '✅ Thank you!\n\nYour signal has been recorded anonymously and added to your ward\'s data.\n\nYou can see the public dashboard at:\n🔗 hamiri.ke\n\nYour voice creates accountability! 🗳️', time: '3:46 PM' }
  ],
  kiswahili: [
    { type: 'bot' as const, text: 'Habari! Mimi ni Hamiri Ke Bot 🇰🇪\n\nNinasaidia kufuatilia fedha za kampeni kwa kukusanya ishara za wananchi kama wewe bila kutambulisha.\n\nUtambulisho wako KAMWE huhifadhiwa. Je, ungependa kuendelea?', time: '3:45 PM' },
    { type: 'user' as const, text: 'Ndiyo', time: '3:45 PM' },
    { type: 'bot' as const, text: 'Vizuri! Swali fupi:\n\nJe, pesa ya ununuzi wa kura imefika eneo lako wiki hii?\n\n1️⃣ NDIYO\n2️⃣ HAPANA\n3️⃣ SIJUI\n\nJibu kwa 1, 2, au 3', time: '3:45 PM' },
    { type: 'user' as const, text: '1', time: '3:46 PM' },
    { type: 'bot' as const, text: '✅ Asante sana!\n\nIshara yako imerekodiwa bila kutambulisha na imeongezwa kwa data ya kata yako.\n\nUnaweza kuona dashibodi ya umma:\n🔗 hamiri.ke\n\nSauti yako inasababisha uwajibikaji! 🗳️', time: '3:46 PM' }
  ],
  sheng: [
    { type: 'bot' as const, text: 'Niaje! Mi ni Hamiri Ke Bot 🇰🇪\n\nNinasaidia kufuatilia doh ya kampeni na kukusanya vibe za watu kama wewe bila kukuexpose.\n\nJina yako HAIPATIKANI hapa. Tuendelee?', time: '3:45 PM' },
    { type: 'user' as const, text: 'Sawa', time: '3:45 PM' },
    { type: 'bot' as const, text: 'Poa! Swali moja tu:\n\nSasa - doh ya kura imefika mtaa wako wiki hii?\n\n1️⃣ NDIYO\n2️⃣ HAPANA\n3️⃣ SIJUI\n\nTuma 1, 2, ama 3', time: '3:45 PM' },
    { type: 'user' as const, text: '1', time: '3:46 PM' },
    { type: 'bot' as const, text: '✅ Asante bro!\n\nSignal yako imeingia safe na imeongezwa kwa data ya area yako.\n\nCheck dashibodi hapa:\n🔗 hamiri.ke\n\nVoice yako inatengeneza accountability! 🗳️', time: '3:46 PM' }
  ]
};

export function WhatsAppFlowDemo() {
  const [language, setLanguage] = useState<'english' | 'kiswahili' | 'sheng'>('english');
  const [messageIndex, setMessageIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  const currentMessages = conversationFlows[language].slice(0, messageIndex + 1);

  const startDemo = () => {
    setIsPlaying(true);
    setMessageIndex(0);
    
    conversationFlows[language].forEach((_, idx) => {
      setTimeout(() => {
        setMessageIndex(idx);
        if (idx === conversationFlows[language].length - 1) {
          setIsPlaying(false);
        }
      }, idx * 1500);
    });
  };

  const resetDemo = () => {
    setMessageIndex(0);
    setIsPlaying(false);
  };

  return (
    <div className="w-full max-w-6xl mx-auto py-8">
      <h2 className="text-3xl font-bold text-center mb-4 text-gray-900">
        WhatsApp Bot Conversation Flow
      </h2>
      <p className="text-center text-gray-600 mb-8 max-w-2xl mx-auto">
        See how citizens interact with Hamiri.ke via WhatsApp - conversational, multilingual, and completely anonymous.
      </p>

      {/* Controls */}
      <div className="flex justify-center gap-4 mb-8 flex-wrap">
        <button
          onClick={startDemo}
          disabled={isPlaying}
          className="px-6 py-3 rounded-lg font-semibold text-white shadow-lg hover:shadow-xl transition-all disabled:opacity-50"
          style={{ backgroundColor: '#ff3a21' }}
        >
          {isPlaying ? 'Playing...' : '▶ Play Conversation'}
        </button>
        
        <button
          onClick={resetDemo}
          className="px-6 py-3 rounded-lg font-semibold text-white shadow-lg hover:shadow-xl transition-all"
          style={{ backgroundColor: '#0b65b1' }}
        >
          ↻ Reset
        </button>
        
        <select
          value={language}
          onChange={(e) => {
            setLanguage(e.target.value as any);
            resetDemo();
          }}
          className="px-4 py-3 rounded-lg border-2 font-semibold"
          style={{ borderColor: '#0b65b1', color: '#0b65b1' }}
        >
          <option value="english">🇬🇧 English</option>
          <option value="kiswahili">🇰🇪 Kiswahili</option>
          <option value="sheng">💬 Sheng</option>
        </select>
      </div>

      {/* Message Counter */}
      <div className="text-center mb-6">
        <div className="inline-flex items-center gap-2 bg-gray-100 px-4 py-2 rounded-full">
          <span className="text-sm font-semibold">Message {messageIndex + 1} of {conversationFlows[language].length}</span>
          <div className="flex gap-1">
            {conversationFlows[language].map((_, idx) => (
              <div
                key={idx}
                className={`w-2 h-2 rounded-full transition-all ${
                  idx <= messageIndex ? 'bg-[#ff3a21]' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Mobile Display */}
      <div className="flex justify-center mb-8">
        <motion.div
          key={`whatsapp-${language}-${messageIndex}`}
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.3 }}
        >
          <MobileDevice variant="android">
            <WhatsAppScreen messages={currentMessages} />
          </MobileDevice>
        </motion.div>
      </div>

      {/* Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
        <div className="bg-white rounded-lg shadow-lg p-6 border-l-4" style={{ borderLeftColor: '#ff3a21' }}>
          <div className="text-3xl mb-3">🌍</div>
          <h3 className="font-bold mb-2">Multilingual Support</h3>
          <p className="text-sm text-gray-600">
            Conversations in English, Kiswahili, Sheng, and local dialects. The bot adapts to user preferences automatically.
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 border-l-4" style={{ borderLeftColor: '#0b65b1' }}>
          <div className="text-3xl mb-3">🔒</div>
          <h3 className="font-bold mb-2">Complete Anonymity</h3>
          <p className="text-sm text-gray-600">
            Phone numbers are hashed immediately. Only ward-level aggregated data is stored. Individual responses are never visible.
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 border-l-4" style={{ borderLeftColor: '#ff3a21' }}>
          <div className="text-3xl mb-3">⚡</div>
          <h3 className="font-bold mb-2">30-Second Interaction</h3>
          <p className="text-sm text-gray-600">
            Quick, simple questions that take minimal time. No complex forms, no lengthy surveys - just honest signals.
          </p>
        </div>
      </div>

      {/* Technical Details */}
      <div className="mt-12 bg-gradient-to-r from-[#ff3a21] to-[#0b65b1] rounded-xl p-8 text-white">
        <h3 className="text-2xl font-bold mb-6">WhatsApp Integration Details</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-bold mb-3 flex items-center gap-2">
              <span>💬</span> Bot Capabilities
            </h4>
            <ul className="space-y-2 text-sm">
              <li>• Natural language processing for casual responses</li>
              <li>• Context-aware conversations with follow-up questions</li>
              <li>• Automatic language detection from first message</li>
              <li>• Rich media support (buttons, quick replies)</li>
              <li>• 24/7 availability with instant responses</li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-3 flex items-center gap-2">
              <span>🔧</span> Technical Stack
            </h4>
            <ul className="space-y-2 text-sm">
              <li>• WhatsApp Business API (Cloud API)</li>
              <li>• Webhook handlers for message processing</li>
              <li>• Redis for session management</li>
              <li>• NLP engine for intent recognition</li>
              <li>• Real-time data pipeline to analytics engine</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
