1. Language Selection (First Time Users)

USSD Screen:

Welcome to Hamiri Ke

Choose Language:
1. Kiswahili
2. English
3. Sheng
4. Local Language

If Local Language:

Select Language
1. Kikuyu
2. Luo
3. Kalenjin
4. Luhya
5. Kamba

System saves language preference for future sessions.

2. Main Menu
Hamiri Ke

1. Report Campaign Spending
2. See Spending Trends
3. Learn Your Rights
4. About Hamiri Ke
0. Exit

Most users will choose 1.

3. Report Campaign Spending (Core Feature)
Where did you see campaign spending?

1. Rally/Event
2. Handouts / Cash
3. Transport (Buses, Bodaboda)
4. Posters/Billboards
5. Food / Gifts
6. Other

User selects category.

4. Location Identification

Option A (Preferred – faster)

Select your County:

1. Nairobi
2. Kiambu
3. Nakuru
4. Kisumu
5. Mombasa
6. Other

Next:

Enter your Ward Code
or type Ward Name

Alternative:

Share location

1. County
2. Constituency
3. Ward

System logs geo-level data.

5. Candidate Identification
Who organized the spending?

1. Presidential Candidate
2. Governor Candidate
3. MP Candidate
4. MCA Candidate
5. Party Event
6. Not Sure

Next screen:

Enter candidate name
or party name
6. Estimated Spending

Instead of asking exact numbers, use ranges.

Estimated spending?

1. Below 10,000 KES
2. 10K – 50K
3. 50K – 200K
4. 200K – 1M
5. Above 1M

This helps citizens estimate easily.

7. Evidence Type
Did you see any of these?

1. Cash distribution
2. Food or goods
3. Paid transport
4. Stage/sound setup
5. Posters / banners
6. Other

Multiple reports across users will verify patterns.

8. Crowd Size (Signal Validation)
How many people attended?

1. Below 50
2. 50 – 200
3. 200 – 1000
4. 1000+

This helps estimate real spending scale.

9. Optional Comment
Add short detail (optional)

Example:
"Boda riders paid 500 each"

Type message:
10. Submission Confirmation
Thank you.

Your anonymous report
helps track campaign spending.

Report ID: 84721

1. Submit another report
2. Main menu
0. Exit
Backend Logic (Important)

Each report generates a structured record:

Report ID
Timestamp
County
Constituency
Ward
Spending Category
Candidate
Estimated Amount Range
Evidence Type
Crowd Size
Language

Then the system:

Aggregates reports by ward

Estimates spending clusters

Compares with official declarations

Visualizes discrepancies

Example output:

Ward: Kahawa West

Declared Spending:
KES 500,000

Citizen Signals Estimate:
KES 2.1M

Discrepancy:
+320%